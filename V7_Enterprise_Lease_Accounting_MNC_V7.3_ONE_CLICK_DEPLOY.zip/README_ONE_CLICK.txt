V7.3 Enterprise Lease Accounting - One Click Deployment

HOW TO DEPLOY
1. Extract this ZIP anywhere on the Windows PC.
2. Open the extracted folder.
3. Double-click:
   ONE_CLICK_DEPLOY_AND_RUN.bat
4. The script will:
   - detect Python
   - create .venv
   - install requirements
   - run pytest regression tests
   - launch Streamlit
5. The browser will normally open at http://localhost:8501.

IMPORTANT
- Do not delete the .venv after deployment.
- Keep the existing production V7.3 backup separately.
- Do not use production lease data for the first run.
- If regression tests fail, the launcher stops instead of starting the application.
- Keep the command window open while the application is running.

REQUIREMENT
Python must already be installed on Windows. The script does not silently install Python itself.
