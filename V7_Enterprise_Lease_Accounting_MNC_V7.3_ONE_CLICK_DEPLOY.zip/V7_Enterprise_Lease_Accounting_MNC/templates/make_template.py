from pathlib import Path
import shutil

# The V7.3 template intentionally starts from the original V6.1 input structure.
# Keep this script as a safe copier so running it cannot accidentally reorder/remove
# the original input fields or the Modification / Escalation_Schedule sheets.
BASE = Path(__file__).with_name("MNC_Lease_Import_Template_V7_3.xlsx")
OUTPUT = Path(__file__).with_name("MNC_Lease_Import_Template_V7_3_COPY.xlsx")

if not BASE.exists():
    raise FileNotFoundError(f"Template not found: {BASE}")

shutil.copy2(BASE, OUTPUT)
print(OUTPUT)
