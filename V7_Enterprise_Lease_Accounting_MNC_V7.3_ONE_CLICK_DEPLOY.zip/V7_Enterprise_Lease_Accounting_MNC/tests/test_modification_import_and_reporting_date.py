import os, sqlite3, tempfile, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from db import database
from core.engine import calculate
from datetime import date

def test_modification_import_is_idempotent():
    old=database.DB_PATH
    fd,path=tempfile.mkstemp(suffix='.db'); os.close(fd)
    database.DB_PATH=path
    try:
        database.init_db()
        mid='MOD-TEST-001'
        data={'modification_id':mid,'lease_id':'L1','effective_date':'2026-01-01','mod_type':'Lease Modification','status':'APPROVED'}
        database.add_modification('TEST',data,'tester','ADMIN')
        database.add_modification('TEST',{**data,'new_base_payment':1000},'tester','ADMIN')
        rows=database.list_modifications('TEST')
        assert len(rows)==1
        assert rows[0]['new_base_payment']==1000
    finally:
        database.DB_PATH=old
        try: os.remove(path)
        except FileNotFoundError: pass

def test_future_modification_does_not_change_reporting_date():
    lease={'lease_id':'L1','status':'ACTIVE','contract_date':'2025-01-01','commencement_date':'2025-01-01','expiry_date':'2030-12-31','first_payment_date':'2025-02-01','payment_frequency':'Monthly','payment_timing':'Arrears','base_payment':10000,'escalation_type':'None','escalation_amount':0,'escalation_rate':0,'first_escalation_date':'2025-01-01','escalation_frequency':'Annual','currency':'INR','ib_rate':0.10,'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':0,'deposit_refund_date':None,'deposit_discount_rate':0,'deposit_ecl_rate':0,'deposit_classification':'Not Applicable','ecl_pd':0,'ecl_lgd':0,'reporting_fx_rate':1,'counterparty':'X','cost_center':'C'}
    rd=date(2026,9,5)
    base=calculate(lease,rd)
    future={'modification_id':'MOD-FUT','effective_date':'2027-01-01','mod_type':'Lease Modification','new_base_payment':20000}
    with_future=calculate(lease,rd,modifications=[future])
    assert base['reporting_liability']==with_future['reporting_liability']
    assert base['reporting_rou']==with_future['reporting_rou']

if __name__=='__main__':
    test_modification_import_is_idempotent(); test_future_modification_does_not_change_reporting_date(); print('2 passed')
