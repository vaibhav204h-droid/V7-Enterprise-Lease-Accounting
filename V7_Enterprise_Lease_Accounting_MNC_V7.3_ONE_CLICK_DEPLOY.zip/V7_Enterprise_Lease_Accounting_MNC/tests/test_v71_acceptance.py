import sys, random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from datetime import date, timedelta
from decimal import Decimal
from core.engine import *

def base(**kw):
    x={'lease_id':'T','commencement_date':'2026-04-01','expiry_date':'2031-03-31','first_payment_date':'2026-04-01','payment_frequency':'Monthly','payment_timing':'Arrears','base_payment':100000,'escalation_type':'None','ib_rate':0.08,'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':0,'reporting_fx_rate':1,'currency':'INR','deposit_discount_rate':0,'deposit_ecl_rate':0,'ecl_pd':0,'ecl_lgd':0}
    x.update(kw); return x

def test_lease_count_fixture():
    ids=[f'L-{i:03d}' for i in range(1,11)]
    assert len([x for x in ids if x.strip()])==10

def test_l001_multi_event_escalation():
    l=base(base_payment=350000,escalation_schedule_json='[{"effective_date":"2027-04-01","type":"Fixed %","value":0.06},{"effective_date":"2029-04-01","type":"Fixed Amount","value":25000},{"effective_date":"2030-04-01","type":"Fixed %","value":0.08}]',expiry_date='2031-03-31')
    assert payment_amount(l,date(2027,4,1))==Decimal('371000.00')
    assert payment_amount(l,date(2029,4,1))==Decimal('396000.00')
    assert payment_amount(l,date(2030,4,1))==Decimal('427680.00')

def test_cross_lease_escalation_isolated():
    a=base(lease_id='L-001',escalation_schedule_json='[{"effective_date":"2027-04-01","type":"Fixed %","value":0.06}]')
    b=base(lease_id='L-002',escalation_schedule_json='[{"effective_date":"2027-04-01","type":"Fixed %","value":0.10}]')
    assert payment_amount(a,date(2027,4,1))==Decimal('106000.00')
    assert payment_amount(b,date(2027,4,1))==Decimal('110000.00')

def test_independent_pv_matches_engine():
    l=base(); ps=build_payment_schedule(l)
    independent=sum((p['_pv_exact'] for p in ps),Decimal(0))
    assert abs(independent-D(calculate_initial_measurement(l,ps)['initial_liability']))<=Decimal('0.01')

def test_current_noncurrent_reconciles():
    l=base(); c=calculate(l,date(2027,3,31))
    assert abs(c['current_liability']+c['noncurrent_liability']-c['reporting_liability'])<=Decimal('0.01')

def test_fx_units():
    l=base(currency='USD',reporting_fx_rate=84.5); c=calculate(l,date(2027,3,31))
    assert c['fx_liability']['functional_balance']==money(c['reporting_liability']*Decimal('84.5'))

def test_repeated_run_deterministic():
    l=base(); a=calculate(l,date(2027,3,31)); b=calculate(l,date(2027,3,31))
    for k in ('initial_liability','reporting_liability','initial_rou','reporting_rou','current_liability','noncurrent_liability'):
        assert a[k]==b[k]

def test_randomised_10000_engine_invariants():
    rng=random.Random(11610921)
    for i in range(10000):
        start=date(2025+rng.randrange(0,4), rng.randrange(1,13), 1)
        months=rng.choice([12,24,36,48,60,84])
        end=start+relativedelta(months=months)-timedelta(days=1)
        freq=rng.choice(['Monthly','Quarterly','Semi-annual','Annual'])
        timing=rng.choice(['Advance','Arrears'])
        rate=Decimal(str(rng.choice([0,0.05,0.08,0.1,0.15])))
        l=base(lease_id=f'R{i}',commencement_date=start.isoformat(),expiry_date=end.isoformat(),first_payment_date=start.isoformat(),payment_frequency=freq,payment_timing=timing,base_payment=rng.choice([10000,50000,100000,250000]),ib_rate=rate)
        rd=min(end,start+relativedelta(months=rng.randrange(1,months+1)))
        c=calculate(l,rd)
        assert c['initial_liability']>=0
        assert abs(c['current_liability']+c['noncurrent_liability']-c['reporting_liability'])<=Decimal('0.01')
        assert c['je_totals']['status']=='PASS'
