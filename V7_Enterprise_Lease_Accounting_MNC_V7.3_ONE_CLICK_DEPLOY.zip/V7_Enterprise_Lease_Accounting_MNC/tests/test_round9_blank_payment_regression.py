from pathlib import Path
from openpyxl import load_workbook
REPORT=Path(__file__).resolve().parents[1]/'reports'/'Lease_Accounting_V7_3_PAYMENT_BLANKS_FIXED.xlsx'

def test_all_payment_rows_have_formula_and_cached_value():
    wf=load_workbook(REPORT,data_only=False,read_only=True)['02_Payment_Schedule']
    wv=load_workbook(REPORT,data_only=True,read_only=True)['02_Payment_Schedule']
    bad=[]
    for r in range(6,wf.max_row+1):
        if wf.cell(r,1).value and wf.cell(r,3).value not in (None,''):
            if wf.cell(r,5).value in (None,'') or wv.cell(r,5).value in (None,''):
                bad.append(r)
    assert not bad, bad
