
from datetime import date
from core.engine import build_payment_schedule, calculate_contractual_payment

def L(**kw):
    x = {
        'commencement_date': date(2026,4,1),
        'expiry_date': date(2030,3,31),
        'first_payment_date': date(2026,4,1),
        'payment_frequency': 'Monthly',
        'payment_timing': 'Advance',
        'base_payment': 100000,
        'ib_rate': 0.10,
        'escalation_type': 'Custom Schedule',
    }
    x.update(kw)
    return x

def test_mixed_events_are_sequential_and_effective_on_payment_date():
    lease=L(escalation_schedule_json="""[
      {"effective_date":"2027-04-01","type":"Fixed %","value":0.05,"event_sequence":1},
      {"effective_date":"2028-04-01","type":"Fixed Amount","value":10000,"event_sequence":2},
      {"effective_date":"2029-04-01","type":"Reset Amount","value":150000,"event_sequence":3},
      {"effective_date":"2030-01-01","type":"Fixed %","value":0.10,"event_sequence":4}
    ]""")
    assert calculate_contractual_payment(lease,date(2027,3,1))[0] == 100000
    assert calculate_contractual_payment(lease,date(2027,4,1))[0] == 105000
    assert calculate_contractual_payment(lease,date(2028,4,1))[0] == 115000
    assert calculate_contractual_payment(lease,date(2029,4,1))[0] == 150000
    assert calculate_contractual_payment(lease,date(2030,1,1))[0] == 165000

def test_index_uses_current_index_over_base_index_not_value_rate():
    lease=L(escalation_schedule_json="""[
      {"effective_date":"2027-04-01","type":"CPI Linked","value":0.99,
       "base_index_value":100,"index_value":104,"event_sequence":1}
    ]""")
    assert calculate_contractual_payment(lease,date(2027,4,1))[0] == 104000

def test_precommencement_events_do_not_double_escalate_commencement_base():
    lease=L(escalation_schedule_json="""[
      {"effective_date":"2025-04-01","type":"Fixed %","value":0.10,"event_sequence":1},
      {"effective_date":"2027-04-01","type":"Fixed %","value":0.05,"event_sequence":2}
    ]""")
    assert calculate_contractual_payment(lease,date(2026,4,1))[0] == 100000
    assert calculate_contractual_payment(lease,date(2027,4,1))[0] == 105000

def test_schedule_rows_use_authoritative_escalated_payment():
    lease=L(escalation_schedule_json="""[
      {"effective_date":"2027-04-01","type":"Fixed %","value":0.05,"event_sequence":1},
      {"effective_date":"2028-04-01","type":"Fixed Amount","value":10000,"event_sequence":2}
    ]""")
    ps=build_payment_schedule(lease)
    by_date={p['payment_date']:p['payment'] for p in ps}
    assert by_date[date(2027,4,1)] == 105000
    assert by_date[date(2028,4,1)] == 115000
