import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from datetime import date
from decimal import Decimal
from core.engine import *

def lease(**kw):
    x={'lease_id':'V7','commencement_date':'2025-04-01','expiry_date':'2030-03-31','first_payment_date':'2025-04-01','payment_frequency':'Monthly','payment_timing':'Advance','base_payment':100000,'escalation_type':'None','ib_rate':0.09,'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':0,'reporting_fx_rate':1}
    x.update(kw); return x

def test_reporting_fx_is_exposed_for_monetary_balances():
    c=calculate(lease(reporting_fx_rate=83),date(2027,4,1))
    assert c['fx_liability']['functional_balance']==money(c['reporting_liability']*Decimal(83))

def test_effective_term_drives_rou_depreciation_end_date():
    l=lease(extension_reasonably_certain='Yes',extension_option_years=2)
    c=calculate(l,date(2031,4,1))
    assert c['reporting_rou']>0
    c2=calculate(l,date(2032,3,31))
    assert c2['reporting_rou']==Decimal(0)

def test_security_deposit_day_one_difference_is_separate_and_feeds_rou():
    l=lease(deposit_paid=200000,deposit_refund_date='2030-03-31',deposit_discount_rate=0.08)
    c=calculate(l,date(2025,4,1))
    assert c['deposit_day_one_adjustment']>0
    assert c['initial_rou']>calculate_initial_measurement(l,build_payment_schedule(l),restoration_pv=Decimal(0))['initial_rou']

def test_journal_entries_include_deposit_initial_fv_and_day_one_adjustment():
    l=lease(deposit_paid=200000,deposit_refund_date='2030-03-31',deposit_discount_rate=0.08)
    c=calculate(l,date(2027,4,1))
    types=[x['je_type'] for x in c['journal_entries']]
    assert "Security Deposit - Initial FV" in types
    assert "Security Deposit - Day 1 Lease Adjustment" in types
    assert c['je_totals']['status']=='PASS'

def test_invalid_fx_is_rejected():
    try: calculate(lease(reporting_fx_rate=0),date(2027,4,1))
    except CalculationValidationError: return
    assert False
