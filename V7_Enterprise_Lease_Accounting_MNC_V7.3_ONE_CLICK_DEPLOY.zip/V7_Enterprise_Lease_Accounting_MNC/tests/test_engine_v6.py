"""
V6 regression + new-feature test suite.

These tests independently verify the specific numerical claims made in the
external review (rate conversion, payment counts, JE balance, final
liability, deposit EIR) against THIS codebase, and validate the new
lease-term, restoration-provision, modification/remeasurement, maturity
analysis and journal-entry-balance features added in V6.
"""
import sys; from pathlib import Path; sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from datetime import date
from decimal import Decimal
from core.engine import *

def base(**kw):
    l = {'lease_id':'T','commencement_date':'2025-04-01','expiry_date':'2030-03-31','first_payment_date':'2025-04-01',
         'payment_frequency':'Monthly','payment_timing':'Advance','base_payment':90000,'escalation_type':'None',
         'escalation_amount':0,'escalation_rate':0,'first_escalation_date':None,'escalation_frequency':'Annual',
         'ib_rate':0.09,'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':0,
         'gl_rou':'ROU Asset - Other','gl_liability':'Lease Liability','gl_interest':'Finance Cost',
         'gl_bank':'Bank','gl_depreciation':'Depreciation Expense','gl_accum_dep':'Accumulated Depreciation - ROU'}
    l.update(kw)
    return l

# ---------------------------------------------------------------------------
# PART A: rate conversion sanity (review items #1-4)
# ---------------------------------------------------------------------------
def test_ibr_9_percent_is_not_divided_by_100():
    # A 9% annual IBR must NOT collapse into an effective 0.09% monthly rate.
    monthly = annual_to_periodic(0.09, 'Monthly')
    assert Decimal('0.0072') < monthly < Decimal('0.0073'), monthly  # (1.09)^(1/12)-1 = 0.7207%

def test_escalation_rate_used_as_stated_not_divided_by_100():
    # 5% (0.05) must escalate to exactly 105,000 on a 100,000 base -- not 100,050.
    assert calculate_percentage_escalation(100000, 0.05, 1) == Decimal('105000.00')

# ---------------------------------------------------------------------------
# PART B: payment schedule generation (review items #5-14)
# ---------------------------------------------------------------------------
def test_five_year_monthly_lease_generates_60_payments():
    l = base()
    payments = build_payment_schedule(l)
    assert len(payments) == 60, len(payments)

def test_quarterly_and_annual_schedules_are_date_driven():
    l = base(payment_frequency='Quarterly', first_payment_date='2025-04-01')
    assert len(build_payment_schedule(l)) == 20
    l2 = base(payment_frequency='Annual', first_payment_date='2025-04-01')
    assert len(build_payment_schedule(l2)) == 5

def test_advance_vs_arrears_first_payment_discounting():
    adv = base(payment_timing='Advance')
    p_adv = build_payment_schedule(adv)
    assert p_adv[0]['discount_period_years'] == Decimal(0)  # t=0 at commencement
    arr = base(payment_timing='Arrears', first_payment_date='2025-04-30')
    p_arr = build_payment_schedule(arr)
    assert p_arr[0]['discount_period_years'] > Decimal(0)  # discounted from commencement to first arrears date

# ---------------------------------------------------------------------------
# PART D/E/H: initial liability, ROU, liability roll-forward (review #20-41)
# ---------------------------------------------------------------------------
def test_final_period_liability_is_zero_at_lease_end():
    l = base()
    c = calculate(l, date(2030, 3, 31))
    assert c['reporting_liability'] == Decimal('0.00')
    assert c['current_liability'] == Decimal('0.00')
    assert c['noncurrent_liability'] == Decimal('0.00')

def test_current_plus_noncurrent_equals_reporting_liability_midlife():
    l = base()
    c = calculate(l, date(2027, 6, 15))
    assert c['current_liability'] + c['noncurrent_liability'] == c['reporting_liability']

def test_idc_is_not_ignored_in_initial_rou():
    l = base(idc=250000)
    c = calculate(l, date(2025, 4, 1))
    l0 = base()
    c0 = calculate(l0, date(2025, 4, 1))
    assert c['initial_rou'] - c0['initial_rou'] == Decimal('250000.00')

# ---------------------------------------------------------------------------
# PART E: restoration provision (review #27-28)
# ---------------------------------------------------------------------------
def test_restoration_provision_unwinds_over_time():
    l = base(restoration_cost_estimate=500000, restoration_expected_date='2030-03-31', restoration_discount_rate=0.08)
    prov = calculate_restoration_provision(l, date(2028, 4, 1))
    assert prov['initial_pv'] < Decimal('500000.00')  # discounted, so less than the nominal future cost
    assert prov['closing_provision'] > prov['initial_pv']  # unwound (accreted) balance grows toward the nominal cost
    assert prov['closing_provision'] <= Decimal('500000.00')

def test_restoration_cost_feeds_initial_rou():
    l = base(restoration_cost_estimate=500000, restoration_expected_date='2030-03-31', restoration_discount_rate=0.08)
    c = calculate(l, date(2025, 4, 1))
    prov = calculate_restoration_provision(l, date(2025, 4, 1))
    l0 = base()
    c0 = calculate(l0, date(2025, 4, 1))
    assert c['initial_rou'] - c0['initial_rou'] == prov['initial_pv']

# ---------------------------------------------------------------------------
# PART F: lease term assessment (review #30-33)
# ---------------------------------------------------------------------------
def test_extension_reasonably_certain_extends_schedule():
    l = base(extension_reasonably_certain='Yes', extension_option_years=2)
    term = assess_lease_term(l)
    assert term['effective_expiry'] == date(2032, 3, 31)
    c = calculate(l, date(2025, 4, 1))
    assert c['payments'][-1]['payment_date'] <= date(2032, 3, 31)
    assert len(c['payments']) == 84  # 7 years of monthly payments

def test_no_option_fields_leaves_term_unchanged():
    l = base()
    term = assess_lease_term(l)
    assert term['effective_expiry'] == term['contractual_expiry'] == date(2030, 3, 31)

def test_termination_reasonably_certain_shortens_schedule():
    l = base(termination_reasonably_certain='Yes', termination_option_date='2028-03-31')
    term = assess_lease_term(l)
    assert term['effective_expiry'] == date(2028, 3, 31)

# ---------------------------------------------------------------------------
# PART J: Ind AS 109 deposit (review #44-50) -- confirm EIR accretion is not static
# ---------------------------------------------------------------------------
def test_deposit_carrying_amount_accretes_not_static():
    l = base(deposit_paid=200000, deposit_refund_date='2030-03-31', deposit_discount_rate=0.08, deposit_ecl_rate=0.01)
    d1 = calculate_security_deposit(l, date(2026, 4, 1))
    d2 = calculate_security_deposit(l, date(2028, 4, 1))
    assert d2['gross_carrying_amount'] > d1['gross_carrying_amount']  # grows via EIR unwinding toward the refund amount
    assert d1['gross_carrying_amount'] > Decimal('0.00')

# ---------------------------------------------------------------------------
# PART L: modification / remeasurement engine (review #56-61)
# ---------------------------------------------------------------------------
def test_rent_revision_modification_remeasures_liability_and_rou():
    l = base()
    mods = [{'effective_date':'2027-04-01','mod_type':'Rent Revision','new_base_payment':120000,'new_ib_rate':0.10}]
    c_before = calculate(l, date(2027, 3, 31))  # day before modification
    c_after = calculate(l, date(2027, 4, 2), modifications=mods)
    assert len(c_after['modification_log']) == 1
    mlog = c_after['modification_log'][0]
    # Revised liability should differ from the carrying amount just before the modification --
    # that's the whole point of remeasurement, and the delta must have moved the ROU asset.
    assert mlog['revised_liability'] != mlog['old_liability']
    assert mlog['rou_adjustment'] == money(mlog['revised_liability'] - mlog['old_liability'])

def test_modification_liability_still_amortises_to_zero_at_term_end():
    l = base()
    mods = [{'effective_date':'2027-04-01','mod_type':'Rent Revision','new_base_payment':120000,'new_ib_rate':0.10}]
    c = calculate(l, date(2030, 3, 31), modifications=mods)
    assert c['reporting_liability'] == Decimal('0.00')

def test_modification_journal_entries_still_balance():
    l = base()
    mods = [{'effective_date':'2027-04-01','mod_type':'Rent Revision','new_base_payment':120000,'new_ib_rate':0.10}]
    c = calculate(l, date(2028, 9, 5), modifications=mods)
    assert c['je_totals']['status'] == 'PASS'
    assert c['je_totals']['difference'] == Decimal('0.00')

def test_modification_carrying_amount_before_is_not_falsely_zero():
    # Regression: the per-regime schedule used to compute the carrying amount immediately
    # before a mid-life modification must reflect the FULL original payment stream, not a
    # schedule artificially truncated at the modification date -- otherwise every
    # modification on an unexpired lease would show a (wrong) zero opening balance.
    l = base(payment_timing='Arrears', first_payment_date='2025-04-30')
    mods = [{'effective_date':'2027-04-01','mod_type':'Rent Revision','new_base_payment':120000,'new_ib_rate':0.10}]
    c = calculate(l, date(2028, 6, 5), modifications=mods)
    mlog = c['modification_log'][0]
    assert mlog['old_liability'] > Decimal('1000000.00')  # a multi-year lease roughly two years into a five-year term

def test_scope_decrease_modification_can_trigger_pl_gain():
    # A large enough liability decrease relative to the ROU carrying amount must cap ROU at
    # zero and push the excess to profit or loss rather than letting ROU go negative.
    l = base(base_payment=90000, idc=0, prepaid=0)
    mods = [{'effective_date':'2026-04-01','mod_type':'Partial Termination','new_base_payment':1000,'new_ib_rate':0.09}]
    c = calculate(l, date(2026, 4, 2), modifications=mods)
    mlog = c['modification_log'][0]
    if mlog['revised_liability'] - mlog['old_liability'] < 0:
        # if the decrease exceeds carrying ROU, pl_gain_loss should be > 0 and ROU schedule should not go negative
        assert all(D(row['closing']) >= Decimal('0.00') for row in c['rou_schedule'])

# ---------------------------------------------------------------------------
# Journal entries always balance (review #71) -- across every prior scenario
# ---------------------------------------------------------------------------
def test_journal_entries_balance_for_plain_lease():
    l = base(idc=50000, prepaid=20000, deposit_paid=100000, deposit_refund_date='2030-03-31', deposit_discount_rate=0.07)
    c = calculate(l, date(2027, 9, 5))
    assert c['je_totals']['debit_total'] == c['je_totals']['credit_total']
    assert c['je_totals']['status'] == 'PASS'

# ---------------------------------------------------------------------------
# Maturity analysis (review #81) -- buckets reconcile to total future undiscounted payments
# ---------------------------------------------------------------------------
def test_maturity_buckets_reconcile_to_total_future_payments():
    l = base()
    c = calculate(l, date(2027, 4, 1))
    total_future = sum((D(p['payment']) for p in c['payments'] if p['payment_date'] > date(2027, 4, 1)), Decimal(0))
    bucket_total = sum(c['maturity'].values(), Decimal(0))
    assert money(total_future) == bucket_total
