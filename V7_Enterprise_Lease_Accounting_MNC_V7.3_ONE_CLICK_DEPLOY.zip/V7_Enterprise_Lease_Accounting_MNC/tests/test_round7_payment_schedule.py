import sys
from datetime import date
from decimal import Decimal
sys.path.insert(0, '.')
from core.engine import calculate, build_payment_schedule


def L(**kw):
    base=dict(
        status='Active', currency='INR', prepaid=0, idc=0, restoration_pv=0, lease_incentive=0,
        deposit_paid=0, deposit_refund_date=None, deposit_discount_rate=0, deposit_ecl_rate=0,
        ecl_pd=0, ecl_lgd=0, reporting_fx_rate=1, extension_option_years=0,
        extension_reasonably_certain='No', termination_reasonably_certain='No', purchase_option_reasonably_certain='No',
        restoration_cost_estimate=0, restoration_expected_date=None, restoration_discount_rate=0,
        validation_tolerance=.01
    )
    base.update(kw); return base


def test_fixed_amount_annual_escalation():
    lease=L(commencement_date='2025-10-01', expiry_date='2029-09-30', first_payment_date='2025-10-01',
            payment_frequency='Monthly', payment_timing='Advance', base_payment=90000, ib_rate=.11,
            escalation_type='Fixed Amount', escalation_amount=5000, first_escalation_date='2026-10-01',
            escalation_frequency='Annual')
    p=build_payment_schedule(lease)
    amounts={x['payment_date'].isoformat():x['payment'] for x in p}
    assert amounts['2026-09-01']==Decimal('90000.00')
    assert amounts['2026-10-01']==Decimal('95000.00')
    assert amounts['2027-10-01']==Decimal('100000.00')
    assert amounts['2028-10-01']==Decimal('105000.00')


def test_biennial_escalation_is_24_months():
    lease=L(lease_id='TC-BIENNIAL',commencement_date='2025-07-01', expiry_date='2031-06-30', first_payment_date='2025-07-01',
            payment_frequency='Quarterly', payment_timing='Advance', base_payment=300000, ib_rate=.10,
            escalation_type='Fixed %', escalation_rate=.05, first_escalation_date='2027-07-01',
            escalation_frequency='Biennial')
    p=build_payment_schedule(lease)
    by={x['payment_date'].isoformat():x['payment'] for x in p}
    assert by['2027-07-01']==Decimal('315000.00')
    assert by['2028-07-01']==Decimal('315000.00')
    assert by['2029-07-01']==Decimal('330750.00')
    assert by['2029-10-01']==Decimal('330750.00')


def test_advance_first_payment_is_not_in_initial_liability():
    lease=L(lease_id='TC-ADV',commencement_date='2025-04-01', expiry_date='2026-03-31', first_payment_date='2025-04-01',
            payment_frequency='Monthly', payment_timing='Advance', base_payment=100000, ib_rate=.09)
    res=calculate(lease,date(2026,3,31))
    assert res['payments'][0]['unpaid_at_commencement'] is False
    assert res['initial_liability']>0
    assert res['advance_at_commencement']==Decimal('100000.00')


def test_arrears_delayed_first_payment_anchors_schedule():
    lease=L(commencement_date='2025-04-01', expiry_date='2026-03-31', first_payment_date='2025-05-01',
            payment_frequency='Monthly', payment_timing='Arrears', base_payment=100000, ib_rate=.09)
    p=build_payment_schedule(lease)
    assert p[0]['payment_date'].isoformat()=='2025-05-01'
    assert len(p)==11


def test_period_count_and_payment_amounts_are_nonblank():
    for typ, amount in [('Fixed %',105000),('Fixed Amount',95000),('None',100000)]:
        lease=L(commencement_date='2025-04-01', expiry_date='2026-03-31', first_payment_date='2025-04-01',
                payment_frequency='Monthly', payment_timing='Advance', base_payment=100000, ib_rate=.09,
                escalation_type=typ, escalation_rate=.05 if typ=='Fixed %' else 0, escalation_amount=5000 if typ=='Fixed Amount' else 0,
                first_escalation_date='2025-10-01', escalation_frequency='Annual')
        p=build_payment_schedule(lease)
        assert len(p)==12
        assert all(x['payment'] is not None and x['payment']>=0 for x in p)
