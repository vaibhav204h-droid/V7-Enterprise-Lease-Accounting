import csv, os, sys
from datetime import date
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.engine import calculate
from core.reporting import make_report

src='/mnt/data/refcsv/Ind_AS_116_Complex_Lease_Test_Pack_20_Cases.csv'
rows=list(csv.DictReader(open(src,encoding='utf-8')))
def num(v):
    v=(v or '').strip()
    if not v: return 0.0
    if v.endswith('%'): return float(v[:-1])/100
    return float(v)

leases=[]
for r in rows:
    et=r['Escalation_Type']
    esc=num(r['Escalation_Rate'])
    leases.append({'lease_id':r['Lease_ID'],'status':'Active','contract_date':r['Contract_Date'],'commencement_date':r['Commencement_Date'],'expiry_date':r['Expiry_Date'],'first_payment_date':r['First_Payment_Date'],'payment_frequency':r['Payment_Frequency'],'payment_timing':r['Payment_Timing'],'base_payment':num(r['Base_Payment']),'escalation_type':et,'escalation_amount':esc if et=='Fixed Amount' else 0,'escalation_rate':esc if et!='Fixed Amount' else 0,'first_escalation_date':r['First_Escalation_Date'],'escalation_frequency':r['Escalation_Frequency'],'currency':r['Currency'],'ib_rate':num(r['IBR']),'prepaid':num(r['Prepaid']),'idc':num(r['Qualifying_IDC']),'restoration_pv':num(r['Restoration_PV']),'lease_incentive':num(r['Lease_Incentive']),'deposit_paid':num(r['Security_Deposit_Paid']),'deposit_refund_date':r['Deposit_Refund_Date'],'deposit_discount_rate':num(r['Deposit_Discount_Rate']),'deposit_ecl_rate':num(r['Deposit_ECL_Rate']),'deposit_classification':r['Deposit_Classification'],'ecl_pd':0,'ecl_lgd':0,'reporting_fx_rate':1,'counterparty':r['Counterparty'],'cost_center':r['Cost_Centre'],'extension_option_years':0,'extension_reasonably_certain':'No','termination_reasonably_certain':'No','purchase_option_reasonably_certain':'No','restoration_cost_estimate':0,'restoration_expected_date':None,'restoration_discount_rate':0,'validation_tolerance':.01,'ecl_method':'Configured loss rate','ecl_horizon_years':1,'ecl_discount_rate':0,'initial_fx_rate':0,'prior_reporting_fx_rate':0,'gl_rou':'ROU Asset - Other','gl_liability':'Lease Liability','gl_interest':'Finance Cost','gl_depreciation':'Depreciation Expense','gl_accum_dep':'Accumulated Depreciation - ROU','gl_bank':'Bank'})
rd=date(2026,9,5)
calcs=[calculate(l,rd) for l in leases]
outdir='/mnt/data/r6/V7_Enterprise_Lease_Accounting_MNC/reports'
path=make_report('ROUND8_TEST',rd,leases,calcs,outdir,audit_rows=[],error_rows=[],company_id='TEST',measurement_basis='Monthly',input_lease_ids=[x['lease_id'] for x in leases],run_id='ROUND8')
print(path)
