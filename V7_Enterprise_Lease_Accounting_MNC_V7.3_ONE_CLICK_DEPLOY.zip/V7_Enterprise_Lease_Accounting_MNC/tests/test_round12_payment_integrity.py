from datetime import date
from core.engine import build_payment_schedule
from core.reporting import _event_formula_with_types, _lease_level_payment_formula


def test_event_formula_has_no_unresolved_placeholders():
    f = _event_formula_with_types(100, [6, 7], {6:'Fixed %', 7:'Fixed Amount'}).format(mr=12, row=100)
    assert '{row}' not in f and '{mr}' not in f
    assert "'01_Lease_Master'!$I$12" in f
    assert "'20_Escalation_Schedule'!$B$6" in f


def test_fixed_schedule_count_matches_contract():
    lease = {
        'commencement_date':date(2018,4,1),'expiry_date':date(2048,3,31),
        'first_payment_date':date(2018,4,1),'payment_frequency':'Annual','payment_timing':'Advance',
        'base_payment':3200000,'escalation_type':'WPI Linked','escalation_rate':0.035,
        'first_escalation_date':date(2019,4,1),'escalation_frequency':'Annual','ib_rate':0.095,
    }
    ps=build_payment_schedule(lease)
    assert len(ps)==30
    assert ps[0]['payment_date']==date(2018,4,1)
    assert ps[-1]['payment_date']==date(2047,4,1)


def test_modified_regime_formula_is_snapshot_formula_safe():
    # Report-layer modified regimes intentionally use engine-snapshot formulas because
    # revised contractual fields are not stored in the original Lease_Master columns.
    f='=ROUND(18070.75,2)'
    assert f.startswith('=ROUND(') and '18070.75' in f


def test_payment_formula_output_gate():
    # Regression guard: every contractual payment row must contain a formula/value.
    # This mirrors the report-layer output-integrity requirement.
    lease = {
        'commencement_date': date(2024,4,1), 'expiry_date': date(2025,3,31),
        'first_payment_date': date(2024,4,30), 'payment_frequency':'Monthly',
        'payment_timing':'Arrears', 'base_payment':50000,
        'escalation_type':'None', 'ib_rate':0.10,
    }
    ps = build_payment_schedule(lease)
    assert ps and all(p.get('payment') is not None for p in ps)
