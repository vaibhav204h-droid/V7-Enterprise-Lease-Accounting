import sys, os, tempfile, json, re
from pathlib import Path
from datetime import date

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

from core.engine import calculate, validate, payment_amount
from core.reporting import make_report
import db.database as db


def lease(i, escalation_type='None'):
    x={
        'lease_id':f'CR-{i:03d}','status':'APPROVED','contract_date':'2026-01-01',
        'commencement_date':'2026-02-01','expiry_date':'2028-01-31','first_payment_date':'2026-02-01',
        'payment_frequency':'Monthly','payment_timing':'Arrears','base_payment':100000+i,
        'escalation_type':escalation_type,'escalation_amount':0,'escalation_rate':0.05,
        'first_escalation_date':'2027-02-01','escalation_frequency':'Annual','currency':'INR','ib_rate':0.08,
        'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':10000,
        'deposit_refund_date':'2028-01-31','deposit_discount_rate':0.06,'deposit_ecl_rate':0.01,
        'deposit_classification':'Pending Assessment','ecl_pd':0.02,'ecl_lgd':0.5,'reporting_fx_rate':1,
        'counterparty':'CP','cost_center':'CC','restoration_cost_estimate':0,'restoration_expected_date':None,
        'restoration_discount_rate':0,'extension_option_years':0,'extension_reasonably_certain':'No',
        'termination_option_date':None,'termination_reasonably_certain':'No','purchase_option_reasonably_certain':'No',
        'validation_tolerance':0.01,'ecl_method':'Configured loss rate','ecl_horizon_years':1,
        'ecl_discount_rate':0,'initial_fx_rate':1,'prior_reporting_fx_rate':1,'gl_liability_extract':None,
    }
    if escalation_type=='Custom Schedule':
        x['escalation_schedule_json']=json.dumps([
            {'effective_date':'2026-08-01','type':'Fixed Rate','value':0.03},
            {'effective_date':'2027-02-01','type':'Fixed Rate','value':0.05},
            {'effective_date':'2027-08-01','type':'Fixed Rate','value':0.04},
            {'effective_date':'2028-01-01','type':'Fixed Amount','value':5000},
            {'effective_date':'2027-11-01','type':'Fixed Rate','value':0.02},
        ])
    elif escalation_type=='CPI Linked':
        x['escalation_schedule_json']=json.dumps([{'effective_date':'2027-02-01','type':'CPI Linked','base_index_value':100,'index_value':105}])
    else:
        x['escalation_schedule_json']=None
    return x


def test_import_replacement_dynamic_20_and_status_preserved():
    fd,path=tempfile.mkstemp(suffix='.db'); os.close(fd)
    old_path=db.DB_PATH; db.DB_PATH=path
    try:
        db.init_db()
        old=[lease(i) for i in range(1,11)]
        for x in old: db.upsert_lease('C',x,'tester','ADMIN')
        new=[lease(i,'Fixed Rate' if i%2==0 else 'None') for i in range(1,21)]
        new[0]['status']='APPROVED'
        ids=db.replace_active_leases_from_import('C',new,'tester','ADMIN')
        rows=db.lease_rows('C')
        assert len(rows)==20
        assert ids=={f'CR-{i:03d}' for i in range(1,21)}
        assert rows[0]['status']=='APPROVED'
        assert rows[-1]['lease_id']=='CR-020'
    finally:
        db.DB_PATH=old_path
        os.unlink(path)


def test_escalation_aliases_and_custom_schedule_work():
    assert payment_amount(lease(1,'Fixed Rate'),date(2027,2,1))==payment_amount(lease(1,'Fixed %'),date(2027,2,1))
    l=lease(2,'CPI Linked')
    assert payment_amount(l,date(2027,2,1)) > payment_amount(l,date(2026,7,1))
    c=lease(3,'Custom Schedule')
    assert payment_amount(c,date(2027,11,1)) > 0


def test_twenty_lease_report_has_dynamic_checks_and_no_magic_decimal_formulas(tmp_path):
    leases=[lease(i, ['None','Fixed Rate','CPI Linked','Custom Schedule'][i%4]) for i in range(1,21)]
    calculations=[calculate(x,date(2027,3,31)) for x in leases]
    out=make_report('CR TEST','2027-03-31',leases,calculations,str(tmp_path),audit_rows=[],error_rows=[],company_id='CRT',input_lease_ids=[x['lease_id'] for x in leases],input_hash='hash',run_id='RUN-20')
    from openpyxl import load_workbook
    wb=load_workbook(out,data_only=False)
    assert len(wb['01_Lease_Master']['A6:A25'])==20
    assert wb['00_Control']['B19'].value.endswith('Import Mismatch")') or 'Import Mismatch' in wb['00_Control']['B19'].value
    assert wb['03_Initial_Recognition']['J6'].value.startswith('=SUMIFS(\'22_Independent_Validation\'!$C:$C')
    assert 'ZERO LIABILITY ON ACTIVE LEASE' in wb['22_Independent_Validation']['F6'].value
    assert wb['08_Journal_Entries']['F6'].value.startswith('=')
    bad=[]
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value,str) and c.value.startswith('=') and re.search(r'\d{5,}\.\d{4,}',c.value):
                    bad.append((ws.title,c.coordinate,c.value))
    assert not bad
