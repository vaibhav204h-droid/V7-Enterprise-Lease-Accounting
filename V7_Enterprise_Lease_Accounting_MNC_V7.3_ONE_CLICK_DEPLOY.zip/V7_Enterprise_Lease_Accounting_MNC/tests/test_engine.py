import sys; from pathlib import Path; sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from datetime import date
from core.engine import *

def base():
 return {'lease_id':'T','commencement_date':'2026-04-01','expiry_date':'2030-03-31','first_payment_date':'2026-04-01','payment_frequency':'Monthly','payment_timing':'Advance','base_payment':90000,'escalation_type':'Fixed Amount','escalation_amount':5000,'escalation_rate':0,'first_escalation_date':'2027-04-01','escalation_frequency':'Annual','ib_rate':0.09,'prepaid':0,'idc':0,'restoration_pv':0,'lease_incentive':0,'deposit_paid':0}

def test_fixed():
 assert calculate_fixed_amount_escalation(90000,5000,0)==90000
 assert calculate_fixed_amount_escalation(90000,5000,1)==95000
 assert calculate_fixed_amount_escalation(90000,5000,2)==100000

def test_percent():
 assert calculate_percentage_escalation(100000,.05,0)==100000
 assert calculate_percentage_escalation(100000,.05,1)==105000
 assert calculate_percentage_escalation(100000,.05,2)==110250

def test_schedule():
 l=base(); p=build_payment_schedule(l); assert len(p)>0; assert p[0]['payment']==90000; assert p[12]['payment']==95000

def test_calculation_reporting_date():
 l=base(); c=calculate(l,date(2026,9,5)); assert c['reporting_liability']>=0; assert c['current_liability']+c['noncurrent_liability']==c['reporting_liability']

def test_deposit():
 l=base(); l.update(deposit_paid=200000,deposit_refund_date='2030-03-31',deposit_discount_rate=.06,deposit_ecl_rate=.01); c=calculate(l,date(2026,9,5)); assert c['deposit']['deposit_fv']>0; assert c['deposit']['ecl_allowance']>=0
