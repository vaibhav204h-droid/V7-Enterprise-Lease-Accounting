
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datetime import date
from decimal import Decimal
import pytest

from core.engine import (
    calculate, payment_amount, build_payment_schedule, calculate_initial_measurement,
    calculate_security_deposit, calculate_ecl, calculate_restoration_provision,
    calculate_fx, assess_lease_term, validate, validate_calculation,
    CalculationValidationError
)
from core.independent_validator import validate_lease


def base(**kw):
    x = {
        "lease_id": "V73",
        "contract_date": "2026-01-01",
        "commencement_date": "2026-04-01",
        "expiry_date": "2030-03-31",
        "first_payment_date": "2026-04-01",
        "payment_frequency": "Monthly",
        "payment_timing": "Arrears",
        "base_payment": 100000,
        "escalation_type": "None",
        "escalation_amount": 0,
        "escalation_rate": 0,
        "first_escalation_date": "",
        "escalation_frequency": "Annual",
        "ib_rate": 0.08,
        "prepaid": 0,
        "idc": 0,
        "restoration_pv": 0,
        "lease_incentive": 0,
        "deposit_paid": 0,
        "reporting_fx_rate": 1,
        "currency": "INR",
        "validation_tolerance": 0.01,
    }
    x.update(kw)
    return x


def test_future_lease_has_no_recognition_or_journal_entries():
    l = base(commencement_date="2027-01-01", expiry_date="2032-12-31",
             first_payment_date="2027-01-01", deposit_paid=200000,
             deposit_refund_date="2032-12-31", deposit_discount_rate=0.06)
    c = calculate(l, date(2026, 12, 31))
    assert c["initial_liability"] == 0
    assert c["initial_rou"] == 0
    assert c["reporting_liability"] == 0
    assert c["reporting_rou"] == 0
    assert c["deposit"]["status"] == "NOT_RECOGNISED_YET"
    assert c["restoration"]["closing_provision"] == 0
    assert c["journal_entries"] == []


def test_future_lease_independent_validator_is_also_zero():
    l = base(commencement_date="2027-01-01", expiry_date="2032-12-31", first_payment_date="2027-01-01")
    c = validate_lease(l, date(2026, 12, 31))
    assert c["initial_liability"] == 0
    assert c["reporting_liability"] == 0
    assert c["current_liability"] == 0


def test_initial_measurement_separates_advance_cash():
    l = base(payment_timing="Advance", first_payment_date="2026-04-01", prepaid=50000)
    ps = build_payment_schedule(l)
    m = calculate_initial_measurement(l, ps)
    assert abs(m["initial_rou"] - (m["initial_liability"] + m["advance_at_commencement"] + Decimal("50000"))) <= Decimal("0.01")
    assert abs(m["initial_liability"] - sum((p["_pv_exact"] for p in ps if p["unpaid_at_commencement"]), Decimal(0))) <= Decimal("0.01")


def test_cpi_wpi_other_index_events_work():
    for typ in ("CPI", "WPI", "Other Index"):
        l = base(escalation_type=typ, base_payment=1000,
                 escalation_schedule_json='[{"effective_date":"2027-04-01","type":"%s","base_index_value":100,"index_value":110}]' % typ)
        assert payment_amount(l, date(2026, 4, 1)) == Decimal("1000.00")
        assert payment_amount(l, date(2027, 4, 1)) == Decimal("1100.00")


def test_index_schedule_rejects_invalid_denominator_and_reason_is_clear():
    l = base(escalation_type="CPI", base_payment=1000,
             escalation_schedule_json='[{"effective_date":"2027-04-01","type":"CPI","base_index_value":0,"index_value":110}]')
    with pytest.raises(CalculationValidationError, match="index"):
        payment_amount(l, date(2027, 4, 1))


def test_current_noncurrent_reconciles_at_reporting_date():
    c = calculate(base(), date(2027, 3, 31))
    assert abs(c["current_liability"] + c["noncurrent_liability"] - c["reporting_liability"]) <= Decimal("0.01")


def test_dynamic_tolerance_is_lease_specific():
    c = calculate(base(validation_tolerance=0.50), date(2027, 3, 31))
    assert c["validation_status"] == "PASS"


def test_dynamic_validation_catches_bad_journal_balance():
    c = calculate(base(), date(2027, 3, 31))
    bad = dict(c)
    bad["journal_entries"] = [dict(x) for x in c["journal_entries"]]
    bad["je_totals"] = dict(bad["je_totals"]); bad["je_totals"]["debit_total"] = Decimal(bad["je_totals"]["debit_total"]) + Decimal("1")
    result = validate_calculation(base(), bad)
    assert result and any("JOURNAL_ENTRY" in e[0] for e in result)


def test_security_deposit_day_one_and_eir_schedule():
    l = base(deposit_paid=200000, deposit_refund_date="2030-03-31", deposit_discount_rate=0.06, deposit_ecl_rate=0.01)
    d = calculate_security_deposit(l, date(2026, 9, 30))
    assert d["deposit_fv"] > 0
    assert d["gross_carrying_amount"] > 0
    assert any(r["interest_income"] >= 0 for r in d["schedule"])


def test_security_deposit_is_zero_before_commencement():
    l = base(deposit_paid=200000, deposit_refund_date="2030-03-31", deposit_discount_rate=0.06)
    d = calculate_security_deposit(l, date(2026, 3, 31))
    assert d["status"] == "NOT_RECOGNISED_YET"


def test_dynamic_ecl_with_cumulative_pd():
    e = calculate_ecl({"ecl_method":"PD x LGD","ecl_pd":0.10,"ecl_lgd":0.50,"ecl_horizon_years":3}, Decimal("100000"))
    expected = Decimal("100000") * (Decimal(1) - (Decimal("0.90") ** Decimal("3"))) * Decimal("0.50")
    assert e["allowance"].quantize(Decimal("0.01")) == expected.quantize(Decimal("0.01"))


def test_restoration_is_zero_before_commencement_and_unwinds_after():
    l = base(restoration_cost_estimate=500000, restoration_expected_date="2030-03-31", restoration_discount_rate=0.08)
    pre = calculate_restoration_provision(l, date(2026, 3, 31))
    post = calculate_restoration_provision(l, date(2027, 3, 31))
    assert pre["closing_provision"] == 0
    assert post["closing_provision"] > 0
    assert post["schedule"] and post["schedule"][-1]["unwinding"] >= 0


def test_modification_preserves_next_contractual_payment():
    l = base(modifications_json='[{"effective_date":"2027-01-15","action":"remeasure","new_base_payment":120000}]')
    c = calculate(l, date(2027, 2, 28), modifications=[{"effective_date":"2027-01-15","mod_type":"Remeasurement","new_base_payment":120000}])
    dates = [p["payment_date"] for p in c["payments"]]
    assert date(2027, 1, 15) not in dates
    assert date(2027, 2, 1) in dates


def test_lease_term_option_changes_effective_expiry_and_rou_end():
    l = base(extension_option_years=24, extension_reasonably_certain="Yes")
    term = assess_lease_term(l)
    assert term["effective_expiry"] > date(2030, 3, 31)
    c = calculate(l, date(2030, 4, 1))
    assert c["reporting_rou"] > 0


def test_fx_remeasurement_exposes_gain_loss():
    fx = calculate_fx({"reporting_fx_rate": 85, "prior_reporting_fx_rate": 80}, Decimal("1000"), Decimal("1000"))
    assert fx["functional_balance"] == Decimal("85000.00")
    assert fx["fx_gain_loss"] == Decimal("5000.00")


def test_month_end_and_leap_year_dates_are_handled():
    l = base(commencement_date="2028-02-29", expiry_date="2029-02-28", first_payment_date="2028-02-29")
    c = calculate(l, date(2028, 2, 29))
    assert c["reporting_liability"] >= 0
    c2 = calculate(l, date(2029, 2, 28))
    assert c2["reporting_liability"] == 0


def test_maturity_separates_future_contractual_payments_from_recognized_balance():
    l = base(commencement_date="2027-01-01", expiry_date="2030-12-31", first_payment_date="2027-01-01")
    c = calculate(l, date(2026, 12, 31))
    assert c["reporting_liability"] == 0
    assert sum(c["maturity"].values()) > 0


def test_input_validation_checks_rates_dates_and_tolerance():
    cases = [
        base(commencement_date="2030-01-01", expiry_date="2029-12-31"),
        base(ib_rate=-1.1),
        base(validation_tolerance=0),
        base(first_payment_date="2026-03-01", payment_timing="Arrears"),
    ]
    for l in cases:
        errors = validate(l)
        assert errors
        assert all(isinstance(e, tuple) and "[" in e[0] for e in errors)


def test_advance_payment_before_commencement_is_allowed_only_as_prepaid():
    l = base(commencement_date="2026-04-01", first_payment_date="2026-03-01", payment_timing="Advance", base_payment=1000)
    ps = build_payment_schedule(l)
    assert ps[0]["payment_date"] < date(2026, 4, 1)
    assert ps[0]["prepaid_before_commencement"] is True


def test_repeated_calculation_is_deterministic():
    l = base(escalation_type="Fixed %", escalation_rate=0.05, first_escalation_date="2027-04-01")
    a = calculate(l, date(2027, 9, 30))
    b = calculate(l, date(2027, 9, 30))
    assert a["reporting_liability"] == b["reporting_liability"]
    assert a["reporting_rou"] == b["reporting_rou"]


def test_expanded_lease_level_escalation_aliases_are_supported():
    cases = [
        ("Fixed Rate", {"escalation_rate": 0.05}, Decimal("1050.00")),
        ("CPI Linked", {"escalation_rate": 0.05}, Decimal("1050.00")),
        ("WPI Linked", {"escalation_rate": 0.05}, Decimal("1050.00")),
    ]
    for typ, extra, expected in cases:
        l = base(escalation_type=typ, base_payment=1000, first_escalation_date="2027-04-01", **extra)
        assert payment_amount(l, date(2027, 4, 1)) == expected


def test_custom_schedule_is_schedule_driven():
    l = base(escalation_type="Custom Schedule", base_payment=1000, escalation_schedule_json='[{"effective_date":"2027-04-01","type":"Fixed Rate","value":0.10}]')
    assert payment_amount(l, date(2027, 4, 1)) == Decimal("1100.00")


def test_original_input_order_is_preserved_in_v73_template():
    from zipfile import ZipFile
    import xml.etree.ElementTree as ET
    p = Path(__file__).resolve().parents[1] / "templates" / "MNC_Lease_Import_Template_V7_3.xlsx"
    with ZipFile(p) as z:
        root = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
        ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        row = root.find("m:sheetData/m:row[@r='1']", ns)
        vals = [c.find("m:is/m:t", ns).text for c in row.findall("m:c", ns) if c.get("t")=="inlineStr"]
        expected_prefix = ["Lease_ID","Contract_Date","Commencement_Date","Expiry_Date","First_Payment_Date","Payment_Frequency","Payment_Timing","Base_Payment","Escalation_Type","Escalation_Amount","Escalation_Rate","First_Escalation_Date","Escalation_Frequency","Currency","IBR","Prepaid","Qualifying_IDC","Restoration_PV","Lease_Incentive","Security_Deposit_Paid","Deposit_Refund_Date","Deposit_Discount_Rate","Deposit_ECL_Rate","Deposit_Classification","ECL_PD","ECL_LGD","Reporting_FX_Rate","Counterparty","Cost_Centre","Restoration_Cost_Estimate","Restoration_Expected_Date","Restoration_Discount_Rate"]
        assert vals[:32] == expected_prefix
        assert vals[32:] == ["Extension_Option_Years","Extension_Reasonably_Certain","Termination_Option_Date","Termination_Reasonably_Certain","Purchase_Option_Reasonably_Certain","Escalation_Schedule_JSON","Validation_Tolerance","ECL_Method","ECL_Horizon_Years","ECL_Discount_Rate","Initial_FX_Rate","Prior_Reporting_FX_Rate"]
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        sheets = [x.get("name") for x in wb.find("m:sheets", ns)]
        assert sheets == ["Lease_Master","Escalation_Schedule","Instructions","Modification"]
