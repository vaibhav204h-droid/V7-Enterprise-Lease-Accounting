from pathlib import Path
from openpyxl import load_workbook

REPORT = Path(__file__).resolve().parents[1] / 'reports' / 'Lease_Accounting_V7.3_TEST_20260905.xlsx'
KEY_SHEETS = ['00_Control','01_Lease_Master','02_Payment_Schedule','03_Initial_Recognition','04_Lease_Liability','05_ROU_Depreciation','06_IndAS109_Deposit','07_Current_NonCurrent','08_Journal_Entries','10_Maturity_Analysis','12_Restoration_Provision','14_Reconciliation','21_Future_Liability','22_Independent_Validation']


def test_round8_report_has_no_excel_error_literals():
    assert REPORT.exists(), f'Missing verification report: {REPORT}'
    wb = load_workbook(REPORT, data_only=True, read_only=False)
    errors = []
    for sname in KEY_SHEETS:
        ws = wb[sname]
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
            for c in row:
                if isinstance(c.value, str) and c.value.startswith('#'):
                    errors.append((sname, c.coordinate, c.value))
    assert errors == []


def test_round8_control_checks():
    wb = load_workbook(REPORT, data_only=True)
    ws = wb['00_Control']
    assert ws['B6'].value == 20
    assert ws['B14'].value == 'PASS'
    assert ws['B18'].value == 20
    assert ws['B19'].value == 'PASS'


def test_round8_reconciliation_is_non_erroring():
    wb = load_workbook(REPORT, data_only=True)
    ws = wb['14_Reconciliation']
    assert all(ws.cell(r,7).value == 'PASS' for r in range(6,26))


def test_round8_key_escalation_transitions():
    wb = load_workbook(REPORT, data_only=True)
    ws = wb['02_Payment_Schedule']
    expected = {
        'TC-006': [(2025,10,90000),(2026,10,95000),(2027,10,100000),(2028,10,105000)],
        'TC-008': [(2025,8,300000),(2027,8,315000),(2029,8,330750)],
        'TC-013': [(2025,11,95000),(2026,11,102500),(2027,11,110000),(2028,11,117500)],
        'TC-014': [(2025,3,550000),(2027,3,583000),(2029,3,617980),(2031,3,655058.8)],
    }
    for lid, checkpoints in expected.items():
        vals=[]
        for r in range(6, ws.max_row+1):
            if ws.cell(r,1).value == lid:
                d = ws.cell(r,4).value
                vals.append((d.year, d.month, ws.cell(r,5).value))
        for y,m,val in checkpoints:
            found=[x for x in vals if x[0]==y and x[1]==m]
            assert found and abs(found[0][2]-val) < 0.01, (lid,y,m,found,val)
