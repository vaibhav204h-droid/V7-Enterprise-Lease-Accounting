from pathlib import Path
import zipfile, xml.etree.ElementTree as ET

REPORT=Path(__file__).resolve().parents[1]/"reports"/"Lease_Accounting_V7_3_ROUND9_PAYMENT_SCHEDULE_REPAIRED.xlsx"
NS={"m":"http://schemas.openxmlformats.org/spreadsheetml/2006/main"}

def test_payment_column_fully_populated():
    with zipfile.ZipFile(REPORT) as z:
        root=ET.fromstring(z.read("xl/worksheets/sheet4.xml"))
        formulas=0; rows=0; blanks=[]
        for row in root.find("m:sheetData",NS).findall("m:row",NS):
            r=int(row.attrib["r"])
            if r<6: continue
            def c_at(ref):
                return next((c for c in row.findall("m:c",NS) if c.attrib.get("r")==ref),None)
            a=c_at(f"A{r}"); e=c_at(f"E{r}")
            if a is None: continue
            rows+=1
            if e is None or e.find("m:f",NS) is None: blanks.append(r)
            else: formulas+=1
        assert rows==1309
        assert formulas==1309, blanks

def test_no_formula_error_literals():
    with zipfile.ZipFile(REPORT) as z:
        bad=[]
        for n in z.namelist():
            if not n.startswith("xl/worksheets/sheet") or not n.endswith(".xml"): continue
            root=ET.fromstring(z.read(n))
            for c in root.iter("{%s}c"%NS["m"]):
                v=c.find("m:v",NS)
                if v is not None and (v.text or "").startswith("#"):
                    bad.append((n,c.attrib.get("r"),v.text))
        assert not bad, bad[:20]
