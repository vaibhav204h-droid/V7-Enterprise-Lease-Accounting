import sys
from datetime import date
from decimal import Decimal
sys.path.insert(0, '.')
from core.engine import build_payment_schedule, calculate, lease_term_months
from core.independent_validator import validate_lease

def base(**kw):
    x=dict(lease_id='T', status='APPROVED', contract_date='2026-01-01',
           commencement_date='2026-09-08', expiry_date='2036-09-07',
           first_payment_date='2026-09-08', payment_frequency='Monthly',
           payment_timing='Advance', base_payment=100000, escalation_type='None',
           escalation_amount=0, escalation_rate=0, first_escalation_date=None,
           escalation_frequency='Annual', currency='INR', ib_rate=.08,
           prepaid=0,idc=0,restoration_pv=0,lease_incentive=0,deposit_paid=0,
           deposit_refund_date=None,deposit_discount_rate=0,deposit_ecl_rate=0,
           deposit_classification='Pending Assessment',ecl_pd=0,ecl_lgd=0,
           reporting_fx_rate=1, counterparty='CP', cost_center='CC',
           restoration_cost_estimate=0, restoration_expected_date=None,
           restoration_discount_rate=0, extension_option_years=0,
           extension_reasonably_certain='No',termination_option_date=None,
           termination_reasonably_certain='No',purchase_option_reasonably_certain='No',
           validation_tolerance=.05,ecl_method='Configured loss rate',
           ecl_horizon_years=1,ecl_discount_rate=0,initial_fx_rate=1,
           prior_reporting_fx_rate=1,gl_liability_extract=None)
    x.update(kw); return x

def test_payment_dates_stay_on_anchor_day():
    l=base(expiry_date='2027-06-30')
    ps=build_payment_schedule(l)
    dates=[p['payment_date'] for p in ps]
    assert dates[:9]==[date(2026,9,8),date(2026,10,8),date(2026,11,8),date(2026,12,8),
                       date(2027,1,8),date(2027,2,8),date(2027,3,8),date(2027,4,8),date(2027,5,8)]

def test_month_end_anchor_does_not_drift():
    l=base(commencement_date='2025-07-31', expiry_date='2026-05-31',
           first_payment_date='2025-07-31')
    ps=build_payment_schedule(l)
    assert [p['payment_date'] for p in ps] == [
        date(2025,7,31),date(2025,8,31),date(2025,9,30),date(2025,10,31),
        date(2025,11,30),date(2025,12,31),date(2026,1,31),date(2026,2,28),
        date(2026,3,31),date(2026,4,30),date(2026,5,31)]

def test_l007_term_is_156_months_and_rou_zero_at_end():
    l=base(expiry_date='2039-09-07')
    assert lease_term_months(l['commencement_date'], l['expiry_date'])==156
    r=calculate(l,date(2039,9,7))
    assert r['lease_term_months']==156
    assert r['reporting_rou']==Decimal('0.00')

def test_independent_validator_uses_assessed_extension_expiry():
    l=base(commencement_date='2026-09-08', expiry_date='2036-09-07',
           first_payment_date='2026-09-08', extension_option_years=3,
           extension_reasonably_certain='Yes')
    iv=validate_lease(l,date(2026,9,14))
    assert iv['assessed_effective_expiry']==date(2039,9,7)
    assert iv['payments'][-1][0] <= date(2039,9,7)

def test_future_modification_does_not_change_reporting_calculation():
    l=base(commencement_date='2026-02-01',expiry_date='2028-01-31',
           first_payment_date='2026-02-01',payment_timing='Advance')
    future={'modification_id':'M1','effective_date':'2027-02-01','approval_status':'APPROVED',
            'mod_type':'Rent Change','new_base_payment':200000}
    r=calculate(l,date(2026,9,14),modifications=[future])
    assert not r['modification_log']
    assert all(p['payment_date'] < date(2027,2,1) or p['payment'] == Decimal('100000.00') for p in r['payments'])
