"""Regression test for Streamlit number_input argument handling.

Streamlit number_input accepts value/min_value as keyword arguments.  Passing the
same value positionally and again as min_value causes:
TypeError: NumberInputMixin.number_input() got multiple values for argument 'min_value'
"""
import ast
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app_v5.py"


def test_no_number_input_duplicates_min_value_positionally():
    source = APP.read_text(encoding="utf-8")
    tree = ast.parse(source)
    offenders = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "number_input":
            keyword_names = {k.arg for k in node.keywords if k.arg}
            if "min_value" in keyword_names and len(node.args) >= 2:
                offenders.append((node.lineno, ast.get_source_segment(source, node)))
    assert offenders == [], f"Duplicate positional min_value detected: {offenders}"
