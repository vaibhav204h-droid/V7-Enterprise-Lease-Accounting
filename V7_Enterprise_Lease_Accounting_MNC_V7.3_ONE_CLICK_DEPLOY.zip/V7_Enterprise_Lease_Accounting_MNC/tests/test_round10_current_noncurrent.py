from pathlib import Path

def test_current_noncurrent_is_anchored_to_engine():
    t=(Path(__file__).parents[1]/"core/reporting.py").read_text(encoding="utf-8")
    assert "SUMIFS(\'04_Lease_Liability\'!$H:$H" in t
    assert "MIN($B{i},SUMIFS(\'21_Future_Liability\'!$F:$F" in t
