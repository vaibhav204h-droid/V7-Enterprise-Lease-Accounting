# Accounting Methods Implemented

1. Annual effective IBR -> periodic effective rate: `(1+r)^(1/n)-1`.
2. Irregular/stub accrual: `(1+r)^(days/365)-1`.
3. Fixed amount escalation: `base + fixed_amount * escalation_number`.
4. Percentage escalation: `base * (1+rate)^escalation_number`.
5. Initial lease liability: PV of unpaid qualifying future lease payments.
6. Initial ROU: liability + qualifying advance/prepaid/IDC/restoration amounts - lease incentives.
7. Liability roll-forward: opening + interest - payment.
8. Reporting date: contractual roll-forward plus stub-period interest after the last scheduled payment date.
9. Current liability: principal component of contractual payments due within 12 months after reporting date, capped at total reporting liability.
10. ROU depreciation: straight-line over the configured lease/useful period, capped at carrying amount.
11. Refundable security deposit: separate Ind AS 109 financial-asset schedule with initial FV, EIR accretion and ECL allowance.
12. ECL: EAD x PD x LGD when approved PD/LGD are supplied; otherwise configured deposit ECL rate is used as an explicit assumption.
