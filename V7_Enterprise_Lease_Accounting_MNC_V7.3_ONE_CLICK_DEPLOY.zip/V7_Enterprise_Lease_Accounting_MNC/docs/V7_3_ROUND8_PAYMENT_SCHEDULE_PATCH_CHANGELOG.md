# V7.3 Round 8 — Payment Schedule Patch Changelog

## Scope
Targeted patch only. Existing workbook sheets, headers, calculation architecture and confirmed working functionality were preserved.

## Payment schedule corrections
- `core/reporting.py::_lease_level_payment_formula` now uses portable Excel/LibreOffice-compatible functions only for lease-level escalation.
- Lease-level escalation is driven by `First_Escalation_Date`, `Escalation_Frequency`, payment date, and the stored escalation amount/rate.
- Supported lease-level escalation types retained: `Fixed %`, `Fixed Rate`, `Fixed Amount`, `CPI`, `CPI Linked`, `WPI`, `WPI Linked`, `Other Index`, and `None`.
- `Fixed Amount` is calculated as Base Payment + (Escalation Amount × contractual escalation count).
- Percentage/index fallback is calculated as Base Payment × (1 + rate)^contractual escalation count.
- Payment outputs are rounded to 2 decimal places so workbook calculations reconcile to the accounting engine's monetary values.
- Biennial escalation is supported as a 24-month contractual frequency.
- Dynamic-array-only functions (`LET`, `FILTER`, `REDUCE`, `SEQUENCE`, `LAMBDA`, `MAXIFS`) are not required by the payment formula.

## Control / reconciliation corrections
- `02_Payment_Schedule!L:L` Engine Cross-check uses the engine's calculated rounded payment value as the execution cross-check, while the separate `22_Independent_Validation` remains the independent reconstruction control.
- `14_Reconciliation!G:G` is null-safe when GL Extract Liability is blank.
- `00_Control` Imported Lease Count is stored as a numeric value, preventing a false Import Mismatch caused by text-vs-number comparison.
- `00_Control` Import Mismatch now compares the bounded imported ID list against the bounded output Lease Master population.
- Recalc status is updated when the report is generated; on Windows with Excel installed, the existing Excel full-recalculation hook can overwrite it with the Excel-specific status.

## Engine correction
- `core/engine.py::annual_to_periodic` now handles `Biennial` payments at the correct two-year effective period.

## Verification
- 65 focused regression tests passed.
- 20-case report generated for reporting date 05-09-2026.
- Report recalculated through LibreOffice headless.
- 0 formula error values (`#VALUE!`, `#REF!`, `#DIV/0!`, `#NAME?`, etc.) detected in the recalculated verification workbook.
- 20 payment schedules generated with matching payment dates and monetary amounts; selected escalation cases verified for TC-001, TC-006, TC-008, TC-013 and TC-014.
- `00_Control`: JE Control = PASS; Import Mismatch = PASS; Imported Lease Count = 20.
- `14_Reconciliation`: all 20 status cells = PASS with blank GL extract handled safely.
- `22_Independent_Validation`: one conservative active-zero-liability CHECK remains for TC-004 because the lease has no remaining unpaid contractual amount at the reporting date despite the contractual expiry being later than the reporting date.
