# V7.3 Round 3 Bug Fix Changelog

1. **04_Lease_Liability** — added a commencement-date Period 1 anchor for every lease block in the supplied workbook. Existing payment schedule rows were preserved and shifted only where the source schedule already used Period 1 so the commencement anchor remains Period 1. The roll-forward formulas now always start from the anchor, preventing the header-row / prior-row reference error.
2. **03_Initial_Recognition!H:H** — corrected the security-deposit day-one adjustment refund-date reference to the fully qualified `01_Lease_Master!V` cell for each lease.
3. **00_Control / workbook recalculation** — workbook calculation metadata is set to automatic/full recalculation on open.
4. **14_Reconciliation!G:G** — status is formula-driven and safely handles an unavailable/blank GL Extract using the Independent-vs-Excel variance.
5. **Future report generation** — `core/reporting.py` contains the same Period 1 and deposit-reference corrections so newly generated reports do not recreate these defects.

**Evidence note:** The user-supplied reference workbook attached for this round contains `LEASE-001` through `LEASE-010` (10 lease IDs). The patch does not invent `LEASE-011` through `LEASE-020`. The final package preserves the supplied workbook and patches the generation logic for the actual 20-lease input run.
