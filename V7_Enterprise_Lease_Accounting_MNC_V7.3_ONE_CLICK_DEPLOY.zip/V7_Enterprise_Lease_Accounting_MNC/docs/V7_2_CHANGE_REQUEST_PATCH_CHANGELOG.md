# V7.2 Change Request — Bug-Fix Patch Changelog

This release is an additive patch on top of the previously delivered V7.3 package. Existing sheet names, report sheet order, core engine APIs, and existing calculation logic are preserved unless specifically required by the change request.

## Bug 1 — Import not linked to actual input / stale data

**Files patched:** `app_v5.py`, `db/database.py`, `core/reporting.py`

- Added `_build_import_lease()` to map the complete V7.3 Lease_Master input, including Status, Contract Date, Restoration PV, extension/termination/purchase fields, Escalation_Schedule_JSON, validation/ECL controls and FX controls.
- Import batch now stores the uploaded SHA-256 and the imported Lease_ID list.
- Full-import commit now replaces the active lease population: IDs missing from a new full import are retained in history but removed from the active population; imported IDs are reactivated/updated.
- Existing rows with the same Lease_ID are safely updated rather than duplicated.
- `01_Lease_Master` therefore receives the current imported values rather than retaining stale/demo values.
- `00_Control` rows 18–19 now expose Imported Lease Count and an `Import Mismatch` control against the exact imported Lease_ID list.

## Bug 2 — Only 10 of 20 leases processed

**Files patched:** `app_v5.py`, `db/database.py`

- Import processing is driven by the detected worksheet data rows, not a hardcoded 10-row limit.
- Commit validates duplicate Lease_IDs and stores the complete ID population in the import batch.
- The calculation path continues to iterate over the full active lease population.

A synthetic 20-lease regression report was generated and verified with LEASE-001 through LEASE-020 appearing across the core downstream sheets.

## Bug 3 — Core sheets blank / formula cache / dashboard incomplete

**File patched:** `core/reporting.py`

- Workbook calculation mode is explicitly set to `auto`.
- `fullCalcOnLoad` and `forceFullCalc` remain enabled.
- `00_Control` rows 20–21 now contain `Last Calculated` and `Recalc Status`.
- When Microsoft Excel is available on Windows, the report writer invokes Excel COM `CalculateFullRebuild()` and saves the workbook again, producing Excel-side cached formula results.
- The Excel recalculation helper is optional and fails closed; it does not alter the accounting calculations if Excel is unavailable.

The downstream formula chain remains intact. Formula-driven checks are now linked to independent reconstruction evidence rather than embedded expected numbers.

## Bug 4 — False PASS in independent validation / missing output errors

**Files patched:** `core/reporting.py`

- `22_Independent_Validation!F6:F...` now adds the requested active-zero-liability condition:
  `CHECK — ZERO LIABILITY ON ACTIVE LEASE`
- The check only applies where the lease has commenced and the assessed effective expiry is after the reporting date, so genuine pre-commencement zero balances are not incorrectly flagged.
- `15_Error_Log` now automatically appends HIGH-severity `CORE_OUTPUTS` records when an active, commenced lease has blank/zero Initial Liability, Reporting Liability or Reporting ROU within the lease-specific tolerance.

## Bug 5 — Hardcoded expected values in validation formulas

**Files patched:** `core/reporting.py`, `core/independent_validator.py`

- `03_Initial_Recognition!J6:J...` now references `22_Independent_Validation!J:J` for the independent Initial ROU reconstruction.
- The independent validator separately rebuilds Initial ROU from the lease inputs and independent liability/deposit/restoration calculations.
- `04_Lease_Liability` reporting controls no longer compare against a hardcoded Python number; they reference independent validation evidence.
- The generated workbook was scanned for large decimal constants embedded inside formulas; the patched test report contained **0 such literals**.

## Bug 6 — Hardcoded Journal Entry debit/credit amounts

**File patched:** `core/reporting.py`

- `08_Journal_Entries!F:G` are now formulas, while preserving all existing JE Type, Debit GL and Credit GL labels/row structure.
- Formulas link to the relevant source sheets (`03`, `04`, `05`, `06`, `09`, `12`, `13`) using Lease_ID and, where applicable, JE Date to avoid multiplying recurring amounts across rows.
- `08_Journal_Entries!H:I` balancing logic is preserved.
- `00_Control!B14` continues to be the overall Debit = Credit control.

## Bug 7 — Escalation formula rigidity

**File patched:** `core/reporting.py` only where needed.

- The existing event-driven payment formula already iterates over every populated escalation event row rather than stopping at four events.
- Lease-level payment formulas were strengthened for no-event cases so supported types can still calculate from Lease_Master fields.
- Existing engine support for `Custom Schedule`, `CPI Linked`, `WPI Linked`, `Other Index` and `Fixed Rate` remains intact.
- No sheet or column was removed/reordered and no separate four-row warning layer was introduced because the existing event formula path is already dynamic.

## Tests completed

- Existing V7.3 remediation / startup regression / repair suite: **29 passed**
- Existing engine + repair + remediation + startup + new change-request suite: **58 passed**
- New change-request patch suite: **3 passed**
- Synthetic 20-lease generated report: verified 20 Lease_IDs across the core downstream sheets.
- Generated report formula scan: **0 large embedded decimal expected-value literals**.
- Database full-import replacement test: 10 existing active leases successfully replaced/extended to a 20-lease active population with imported status/value preservation.

## Important validation note

The exact user fixture named `MNC_Lease_Import_Template_V7_3_Dummy_20_Leases.xlsx` was not present in the available runtime at packaging time. Therefore the 20-lease end-to-end test above uses a controlled 20-lease synthetic fixture. The application is patched to process the exact fixture when supplied through the import screen.
