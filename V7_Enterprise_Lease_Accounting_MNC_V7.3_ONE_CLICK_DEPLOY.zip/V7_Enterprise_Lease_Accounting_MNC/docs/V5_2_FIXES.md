# V5.2 Enterprise Fixes

## 1. Reporting date
- Calculation Centre exposes an editable Central Reporting Date.
- Default is `date.today()` at runtime.
- The selected date is stored in Streamlit session state for the run.
- Calculation engine accepts an explicit reporting date; if omitted, it uses the current date.

## 2. Keyboard shortcuts
- Replaced the non-functional postMessage JavaScript shortcut implementation with native Streamlit button shortcuts.
- Requires Streamlit >= 1.60.
- Ctrl+Alt+A: Lease Master / Add
- Ctrl+Alt+I: Import
- Ctrl+Alt+E: Events
- Ctrl+Alt+C: Calculate
- Ctrl+Alt+R: Reports
- Ctrl+Alt+Q: QA
- Ctrl+Alt+T: Audit

## 3. Import
- No hard-coded `/tmp` path.
- Workbook is read from memory using BytesIO.
- Detects `Lease_Master` sheet and scans first 20 rows for the header row.
- Supports V5.1 and legacy V4-style header placement.
- Maps `Escalation_Amount`, which was previously omitted by the importer.
- Uses a staged preview and explicit Confirm & Commit step.
- Creates an import batch ID, SHA-256 hash and company-scoped audit record.

## 4. False negative liability errors
- Internal amortisation now uses unrounded Decimal balances.
- Display values are rounded to cents only.
- Small final-payment rounding residuals up to ₹0.10 are normalised to zero.
- Material negative liabilities still raise a critical calculation error.

This addresses the screenshot errors at TC-003, TC-004, TC-006, TC-007, TC-011, TC-012, TC-017, TC-018 and TC-019 where the prior engine was blocking on small rounding residuals.
