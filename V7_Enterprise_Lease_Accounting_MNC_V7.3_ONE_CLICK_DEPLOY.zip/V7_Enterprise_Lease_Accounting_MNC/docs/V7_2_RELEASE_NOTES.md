# V7.2 Final Forensic Repair — Release Notes

## Release
- Application / Engine / Validation: **V7.2**
- Release type: surgical forensic repair over the V7.1 core architecture.
- Core UI, database, import/export workflow, audit trail, report sheet structure and valid accounting engines were retained.

## Repairs implemented
1. Single authoritative Python lease calculation remains the production calculation source.
2. Escalation event ordering is deterministic by Effective Date + Event Sequence.
3. Excel non-uniform escalation references are scoped to the correct Lease ID rather than fixed global rows.
4. Uniform annual/monthly/quarterly/semi-annual escalation exponent logic corrected.
5. Excel liability roll-forward now starts from Initial Recognition and reporting rows fall back to initial liability when no prior payment row exists.
6. Excel current/non-current is formula-driven from a future-liability projection and uses the next 12-month principal criterion.
7. Reporting and payment dates are stored as real Excel dates rather than text.
8. Initial ROU includes the rounded security-deposit day-one lease adjustment and is formula-linked.
9. ROU depreciation uses the assessed effective expiry and rounded monthly depreciation consistent with the production engine.
10. Security-deposit working is formula-driven for FV, EIR accretion, refund, ECL and net carrying amount.
11. Maturity analysis is formula-linked to the contractual payment schedule.
12. Independent validation module reconstructs payment/PV/liability/current split without calling the production calculate() function.
13. Workbook Engine-vs-Excel reconciliation now references independent validation evidence.
14. ₹0.01 control tolerance applied to the repaired workbook controls.
15. V7.2 acceptance tests added, including L-001, L-008, reporting-date movement, cross-lease isolation and 10,000 randomized independent scenarios.

## Known limitations requiring accounting-policy confirmation
- Foreign-currency treatment remains a reporting conversion layer for monetary balances; full transaction-date FX ledger postings require transaction-level FX data.
- Modification/remeasurement scenarios require client-specific approved modification facts and accounting-policy evidence.
- Restoration provision day-count convention is 365-day basis and should be aligned to the entity's documented policy.
- Security-deposit ECL requires documented management methodology/segmentation and forward-looking assumptions before use as an audit conclusion.

## Certification principle
The V7.2 package is not to be described as universally audit-ready solely from software tests. Audit readiness remains dependent on approved inputs, accounting-policy conclusions, source evidence, GL reconciliation and client-specific review.
