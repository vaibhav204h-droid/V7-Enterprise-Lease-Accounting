# Excel Recovery / Formula-Length Fix

## Root cause found
The generated `02_Payment_Schedule!E:E` escalation formulas were expanding into deeply nested IF expressions. Several formulas reached Excel's formula-length ceiling (32,767 characters), which can trigger Excel's "We found a problem with some content" recovery behaviour and removal of formula records on open.

## Targeted patch
- Replaced only the payment amount formula in `02_Payment_Schedule!E6:E...` with a compact Excel 365 `LET/FILTER/REDUCE` expression.
- Existing columns, sheet names, layout, headers, and downstream formulas are unchanged.
- The compact formula processes an arbitrary number of escalation rows rather than the previous 4-tier expansion.
- Existing escalation types including Fixed %, Fixed Rate, Fixed Amount, Reset Amount, CPI/CPI Linked, WPI/WPI Linked and index-type fallbacks are recognized.
- Set workbook calculation mode to automatic with full recalculation on load.

## Validation
- No formula exceeds 8,192 characters in the repaired workbook.
- All workbook XML parts parse successfully.
- ZIP integrity test passes.
- OpenPyXL load/save round-trip passes.
