# V5.1 Import Workflow Fix

## Root cause
The prior importer relied on a two-click Streamlit flow. Streamlit reruns the script after every button click, so validation state had to be persisted before the confirmation step. In addition, legacy V4 report workbooks could have title rows above the Lease_Master headers and different header names.

## Fix
1. Uploaded workbook is identified by SHA-256 content hash.
2. Validation is automatically executed once for a new upload.
3. Validated data is stored in `st.session_state.import_preview`.
4. The application reruns once and renders the persistent Import Preview and Confirm button.
5. The confirmation button is outside the validation button block and therefore remains clickable on the next Streamlit rerun.
6. Header row detection scans the first 15 rows.
7. Official V5.1 headers and common V4 Lease_Master headers are mapped to canonical fields.
8. New vs existing Lease IDs are shown as ADD vs UPDATE in the preview.
9. Temporary files use `tempfile.NamedTemporaryFile`, so Windows does not depend on `/tmp`.
10. Technical errors are captured with an Import Error ID and company-wise audit entry.

## User flow
Upload Excel -> automatic validation -> Import Preview -> Confirm Import -> Company Lease Master.
