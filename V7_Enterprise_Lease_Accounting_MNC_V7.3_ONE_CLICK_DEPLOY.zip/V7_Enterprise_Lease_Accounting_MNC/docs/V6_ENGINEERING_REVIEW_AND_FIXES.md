# V6.0 Engineering Review & Fixes

## What I actually reviewed

You gave me three things:

1. `V5_Enterprise_Lease_Accounting_MNC.zip` and `..._V5_2_ENTERPRISE.zip` — a Python/Streamlit/SQLite
   lease accounting application (not an Excel/VBA workbook).
2. `Ind_AS_116_Ind_AS_109_Lease_Software_External_Review_Changes.docx` — a detailed external review.

**Important finding, stated plainly:** the external review document describes a different, much more
primitive artefact than the code in the zip files. It refers repeatedly to spreadsheet mechanics —
formulas that divide a 9% IBR by 100, journal-entry formulas that "refer to Lease Master columns such
as AY, AZ and BE", `IFERROR(...,0)` hiding errors — none of which exist anywhere in this Python codebase.
Those are Excel-formula defects, not Python defects. I checked the actual `core/engine.py` in the
V5.2 zip line by line: the rate conversion is already done correctly
(`(1+annual_rate)**(1/n)-1`, not `/100`), the payment schedule is generated from dates rather than a
fixed row count, and the current/non-current split, escalation logic, and Ind AS 109 deposit EIR
schedule were all already sound and independently re-verified by the test suite in this delivery.

I'm telling you this rather than silently rebuilding from scratch, because pretending the whole thing
was broken when large parts of it were not would be exactly the kind of false-confidence problem the
review itself is warning about ("no PASS merely because a flawed process agrees with itself").

That said, the review's *checklist* (lease term assessment, restoration provision, modification/
remeasurement, maturity analysis, a genuine journal-entry balance control, a reconciliation control
that doesn't fake a GL match) is a legitimate list of what a complete Ind AS 116/109 engine needs, and
I used it to test the actual Python codebase. Several of those really were missing. That work is V6.0.

## Gaps that were real, and what V6.0 does about them

| Gap found in the actual codebase | V6.0 fix |
|---|---|
| Lease term was always the contractual expiry date — no assessment of extension/termination options reasonably certain to be exercised (Ind AS 116 paras 18-19) | `assess_lease_term()` — extends or shortens the term used for the payment schedule and depreciation when you mark an option reasonably certain |
| Restoration/dismantling cost was a single flat number with no discounting or unwinding | `calculate_restoration_provision()` — discounts an estimated future cost to PV at commencement and unwinds it to profit or loss on its own schedule |
| Lease modifications (rent revisions, scope changes, term changes) were logged as free-text events but **never affected any calculation** — the liability, ROU and journal entries were the same whether a modification existed or not | A full remeasurement engine (`build_regimes` / `calculate_lease_with_modifications`): at a modification's effective date, the liability is remeasured to the PV of the revised remaining payments, the difference adjusts the ROU asset, and any excess decrease is taken to P&L (Ind AS 116 paras 44-46) |
| No maturity analysis (Ind AS 116 para 58 / Ind AS 107 paras 39, B11-B11D) | `maturity_analysis()` — undiscounted contractual payments bucketed `<1yr, 1-2, 2-3, 3-4, 4-5, >5yr`, new sheet `10_Maturity_Analysis` |
| Journal entries had no explicit balance control — an out-of-balance run could pass silently | `build_journal_entries()` now returns a totals object; `08_Journal_Entries` has an explicit Total Debit / Total Credit / Difference / PASS-ERROR row, and it's flagged red if it doesn't balance |
| The Reconciliation sheet defaulted the "GL Liability" column to `0` and marked it PASS — i.e. it always passed even with no real GL data behind it | `14_Reconciliation` now shows "GL EXTRACT NOT PROVIDED" until you actually enter a GL trial-balance figure (`gl_liability_extract` on the lease); it never fakes a pass |

## A real, separate bug I found while testing the whole pipeline end-to-end (not from the review doc)

Testing isolated functions is not the same as testing the actual app. Running the full workflow —
create lease → create event → approve → calculate portfolio → generate report — through the database
layer (not just the engine in isolation) turned up a genuine defect that would have hit you the first
time you clicked **Calculate Portfolio** in the real app:

- `lease_rows()` returns `sqlite3.Row` objects, which do not support `.get()`. `core/reporting.py`'s
  `01_Lease_Master` sheet calls `lease.get(col)` for every field. **Every real report generation
  through the app would have raised `AttributeError` and crashed** — this wasn't reachable from the
  engine unit tests because they call `calculate()` with plain dicts, never through the database.
  Fixed in `app_v5.py` by normalising `lease_rows()` results to plain dicts once, at the top of the
  Calculation Centre page.
- Related: the saved report filename embedded the **company name** (which can contain spaces, e.g.
  "VGH Shipyards Pvt Ltd"), while the Reports page searched for files by **company ID**. The two could
  never match, so a generated report could become invisible in the Reports tab. `make_report()` now
  takes an explicit `company_id` for the filename, separate from the display name shown inside the
  workbook.

I found both of these by actually running the application's own code path end-to-end with a
SQLite-backed company and two leases, not by reading the source. I'd treat "run it end-to-end, not
just unit-test the engine" as a standing QA requirement for anyone touching this codebase in future.

## What I deliberately left as a bug I could **not** verify against a real fact pattern

The modification engine assumes a modification is accounted for as an adjustment to the existing
lease (Ind AS 116 para 45), not as a separate new lease (para 44). Whether a specific real
modification qualifies as a separate lease is a judgement call requiring the actual contract terms —
the engine flags this scenario in the field name (`is_separate_lease` is accepted in the UI) but does
not (and cannot) automate that judgement. Please make sure whoever approves a modification event in
the app has actually made that assessment before recording it.

## Test coverage

`tests/test_engine.py` — the original 5 tests, unchanged and still passing (confirms full backward
compatibility with the existing engine).

`tests/test_engine_v6.py` — 21 new tests, written to independently re-verify the specific numerical
claims in the external review against this codebase (rate conversion, payment counts, current/
non-current reconciliation, final-period liability, IDC, restoration provision, lease term
assessment, deposit EIR accretion, modification remeasurement, journal balance, maturity buckets) —
including a regression test for the mid-life-modification bug described above, which I found and
fixed while building this out. All 26 tests pass.

## What's genuinely out of scope for a code review/fix pass like this

- A full probability-of-default/loss-given-default ECL model calibrated to your counterparties (the
  engine will use PD × LGD if you supply them; otherwise it falls back to a configured flat rate — this
  was already true in V5.2 and is a data/policy input, not a code defect)
- SSO/MFA, formal change-management sign-off workflows beyond the existing Maker-Reviewer-Approver
  status flags, and direct ERP/GL system integration (the Reconciliation sheet now has a place for a
  real GL extract, but pulling one automatically needs an actual connection to your GL, which nobody
  has given me credentials or an API for)
- Independent audit sign-off — this delivery gives you a properly tested calculation engine and a
  transparent, checkable output; it is not a substitute for your (or your firm's) own review of a
  specific client's leases against these mechanics

## Post-delivery fix: Streamlit runtime compatibility (found when you actually ran it)

Running the app on your machine surfaced a real crash I hadn't hit in my own testing, because my
earlier smoke test only ever reached the login screen, not the authenticated app behind it:

- `StreamlitAPIException: The shortcut cannot use the keys 'C' or 'R'` — your installed Streamlit
  release reserves the bare keys `C` and `R` for its own built-in shortcuts (clear-cache / rerun) and
  rejects any custom shortcut that uses them, modifiers or not. The sidebar's `Calculate` and `Reports`
  navigation shortcuts used `Ctrl+Alt+C` and `Ctrl+Alt+R`. Changed to `Ctrl+Alt+L` and `Ctrl+Alt+P`
  (confirmed against the installed Streamlit's own validation function that these, and all the other
  shortcut letters already in use, are not reserved), and made the fallback in `_navigate_button()`
  catch any shortcut-registration failure (not just the older-Streamlit `TypeError` case it already
  handled) so a future Streamlit reserved-key change degrades to a plain button instead of crashing
  the app again.
- While I was in there: every button and dataframe call used `use_container_width=True`, which
  Streamlit has been warning is deprecated "after 2025-12-31" — a date that has already passed.
  Replaced all 15 occurrences with `width='stretch'` before it actually got removed and took the
  whole UI down with it.

I then drove the app through Streamlit's own `AppTest` framework — actually logging in and clicking
through every single page (Control Centre, Lease Master, Import, Events, Calculate, Reports, Audit
Trail, QA, Users, Company Settings) — rather than just hitting the login screen, and confirmed zero
exceptions on any of them. That's the level of check that should have caught this the first time;
noted so future changes to this app get tested the same way.
