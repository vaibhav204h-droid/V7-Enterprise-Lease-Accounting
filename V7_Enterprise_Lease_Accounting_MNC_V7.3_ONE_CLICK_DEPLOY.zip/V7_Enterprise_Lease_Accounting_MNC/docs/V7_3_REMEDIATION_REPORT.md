# V7.3 Remediation Report

Source: supplied Excel error workbook (`Errors to be fixed`).

| # | Error class | V7.3 treatment |
|---|---|---|
| 1 | Future lease recognition | Recognition is date-gated to commencement. |
| 2 | Future lease liability | Reporting liability is zero before commencement. |
| 3 | Pre-commencement ROU | ROU and depreciation are zero before commencement. |
| 4 | Pre-commencement interest | Liability schedule/stub interest are suppressed before commencement. |
| 5 | Future-lease JEs | Journal entry builder returns no entries before commencement. |
| 6 | Reporting-date contractual cut-off | Closing balances use reporting-date gates; future cash remains in maturity view. |
| 7 | Initial PV/payment timing | Advance cash is separated from unpaid liability; first payment timing is respected. |
| 8 | Escalation boundary/cumulative logic | Ordered events, boundary validation and cumulative event application. |
| 9 | CPI/WPI/Other Index | Index/base values are supported with denominator and date validation. |
| 10 | Current/non-current | Current principal is derived from the next 12 months and reconciles to reporting liability. |
| 11 | Weak PASS validation | Dynamic calculation validation checks accounting invariants before PASS. |
| 12 | Hard-coded benchmarks | Independent validator reconstructs calculations from inputs. |
| 13 | Security deposit | FV, EIR roll-forward and day-one adjustment are calculated separately. |
| 14 | Simplistic ECL | Configurable PD × LGD horizon and loss-rate methodologies. |
| 15 | Restoration provision | Recognition date, discounting, unwinding and final true-up are controlled. |
| 16 | Modification testing | Mid-period remeasurement and next-payment preservation are tested. |
| 17 | Option reassessment | Effective lease expiry is assessed from option inputs. |
| 18 | FX | Reporting FX balance and optional remeasurement gain/loss are exposed. |
| 19 | Final-period ROU | ROU schedule true-ups to zero at effective expiry. |
| 20 | Stub/leap/month-end dates | Date parsing and stub calculations are covered by targeted tests. |
| 21 | Maturity vs recognised liability | Contractual maturity is kept separate from recognised closing liability. |
| 22 | Prepayment/IDC | Initial ROU measurement separately carries prepayment and IDC inputs. |
| 23 | JE event controls | Entries are generated only when their underlying event occurs. |
| 24 | Automatic input checks | Field-level input/rate/date/escalation/deposit/FX controls were added. |
| 25 | Configurable tolerance | Lease-level `validation_tolerance` is supported. |
| 26 | Auditability | Existing audit trail is retained; calculation input/result snapshots are stored. |
| 27 | Exact failure reasons | Validation messages contain field/control tags and reason text. |
| 28 | Dynamic independent validation | Excel report includes formula controls plus engine-vs-independent comparison. |

## Regression test results

- `tests/test_v73_error_remediation.py`: 20 passed.
- `tests/test_v72_acceptance.py -k "not randomized"`: 4 passed.
- Earlier core/V7 deterministic regression set: 39 passed before final V7.3 additions.

The existing 10,000-scenario randomized tests are retained unchanged and can be run separately for extended assurance.
