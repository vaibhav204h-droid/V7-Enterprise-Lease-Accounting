# V7.3 Excel Calculation / Blank Payment Output Fix

## Root cause
The delivered XLSX contained valid formulas in `02_Payment_Schedule!E:E`, but the formula cells had no persisted cached values (`<v>`). The source workbook had 1,309 payment formulas and 1,309 blank cached results. When Excel opened the file in this state, recovery/recalculation could leave the payment output appearing blank.

## Patch
- Preserve the existing workbook/sheet/column/formula structure.
- Use Excel COM full recalculation when Microsoft Excel is available.
- Add a mandatory LibreOffice Calc headless fallback when Excel COM is unavailable.
- Replace the output only after a successful recalculation file is created.
- Persist calculation results before the workbook is delivered.
- The latest supplied workbook was passed through LibreOffice Calc and saved as a clean XLSX with cached payment values.

## Verification
- XLSX ZIP integrity: PASS
- All worksheet XML parts parse: PASS
- `02_Payment_Schedule` formula cells: 1,309
- `02_Payment_Schedule` formula cells with blank cache after Calc save: 0
- Formula error literals in payment results: 0
- 20 lease IDs present in payment schedule: PASS
- Existing formulas retained; only the recalculation/cache pipeline was changed.

## Application behavior going forward
The application will no longer silently deliver a formula-only workbook when Excel COM is unavailable. A portable Calc recalculation pass is attempted before the report is considered ready.
