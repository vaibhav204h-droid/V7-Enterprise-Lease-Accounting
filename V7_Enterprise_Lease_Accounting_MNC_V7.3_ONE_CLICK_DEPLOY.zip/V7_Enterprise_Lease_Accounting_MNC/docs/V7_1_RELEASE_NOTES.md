# V7.1 Forensic Repair — Release Notes

## Status
Controlled V7.1 surgical-repair build. Existing architecture and workflow retained.

## Repairs
1. Central reporting/engine version unified to V7.1.
2. Lease count changed from numeric `COUNT` to non-empty Lease ID `COUNTA`.
3. Calculation-run records now store V7.1 engine version.
4. Existing lease engine retained as authoritative source; downstream reports continue to consume engine results.
5. Security-deposit FV/day-one adjustment/EIR/ECL and FX working retained and covered by acceptance tests.
6. 10,000 randomized engine-invariant scenarios added to QA suite.
7. Existing 31 tests retained; total automated suite now 39 tests.

## QA result
`39 passed` including the 10,000-scenario randomized invariant test.

## Known architectural compatibility
`app_v5.py` is retained by design to preserve the existing project structure and workflow. Legacy V6.0/V6.1 report packs remain readable, but new packs are generated as V7.1.

## Important accounting limitation
FX presentation is explicitly exposed for monetary balances, but a full multi-date FX transaction ledger is not introduced because that would be an architectural expansion beyond the supplied core. Any foreign-currency implementation should be reviewed against the entity's functional-currency and transaction-date facts before audit sign-off.
