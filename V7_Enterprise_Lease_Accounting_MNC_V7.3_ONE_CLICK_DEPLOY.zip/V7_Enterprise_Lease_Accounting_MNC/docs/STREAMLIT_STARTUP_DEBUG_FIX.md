# V7.3 Streamlit Startup Debug Fix

## Error observed
`TypeError: NumberInputMixin.number_input() got multiple values for argument 'min_value'`

## Root cause
Two `st.number_input()` calls in `app_v5.py` supplied the default value as the second positional argument and also supplied `min_value=` as a keyword argument. In Streamlit, the second positional parameter is already `min_value`, so this creates the same-argument-twice TypeError when the Lease Master page is rendered.

Affected fields:
- ECL Horizon (years)
- Validation Tolerance

## Fix
Both calls now pass the default using the explicit `value=` keyword while keeping the intended `min_value=` constraint.

## Validation
A regression test was added at:
`tests/test_streamlit_number_input_regression.py`

The patched `app_v5.py` also passes Python compilation and an AST scan confirms there are no remaining `number_input()` calls in the application that pass `min_value` both positionally and by keyword.
