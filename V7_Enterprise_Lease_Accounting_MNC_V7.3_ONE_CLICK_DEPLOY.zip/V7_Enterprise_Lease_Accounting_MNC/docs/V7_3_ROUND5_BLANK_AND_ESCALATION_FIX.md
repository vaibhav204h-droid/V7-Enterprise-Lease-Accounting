# V7.3 Round 5 — Blank Output & Escalation Fix

## Root causes found
1. The delivered report contained legacy, unquoted numeric-leading worksheet references such as `01_Lease_Master!`. These were interpreted as names by some recalculation engines, producing `#NAME?`/blank cascades.
2. `02_Payment_Schedule!E:E` contained an oversized escalation formula using `MAXIFS`/large nested logic. In the delivered workbook it reached Excel's formula-length limit on some leases and was not portable to the recalculation environment.
3. The generated report and current source code had drifted: the packaged workbook still contained the older escalation formula even though the source contained a newer escalation helper.

## Patch
- All numeric-leading worksheet references in formulas are now explicitly quoted.
- `02_Payment_Schedule!E:E` now uses a compact chronological escalation formula built from contractual event rows.
- The formula supports Fixed %, Fixed Amount, Reset Amount/New Base/Absolute Amount, CPI/WPI/Other Index-linked events and mixed event order without LET/FILTER/REDUCE/SEQUENCE/LAMBDA/MAXIFS.
- The independent payment cross-check uses a separately rendered copy of the same event reconstruction rather than referring to the payment cell itself.
- Workbook calculation mode is automatic with full recalculation on load.

## Verification on the supplied Round-4 report
- No cached formula cells are blank after recalculation.
- No cached `#REF!`, `#VALUE!`, `#NAME?`, `#DIV/0!` or similar calculation errors remain.
- Maximum formula length is below 500 characters for the patched payment formulas.
- Payment rows are non-blank for every lease in the supplied report.
- Escalation examples verified:
  - LEASE-001: 1,200,000 → 1,260,000 → 1,323,000 → 1,389,150 → 1,458,607.50
  - LEASE-002: 450,000 with fixed-amount steps progressing to 475,000, 500,000, etc.
  - LEASE-005 reset event and subsequent percentage event work.
  - LEASE-007 five-event schedule, including reset, works without oversized formulas.
  - LEASE-009 reset + fixed amount works.
  - LEASE-010 percentage escalation works.
- Control dashboard contains populated values and JE control = PASS.

## Environment
The delivered workbook is designed for **Microsoft Excel and LibreOffice-compatible formula syntax** and uses Excel's automatic/full recalculation flags. The validation pass was performed using LibreOffice 25.x in the delivery environment; no dynamic-array-only functions are required for the patched escalation formula.
