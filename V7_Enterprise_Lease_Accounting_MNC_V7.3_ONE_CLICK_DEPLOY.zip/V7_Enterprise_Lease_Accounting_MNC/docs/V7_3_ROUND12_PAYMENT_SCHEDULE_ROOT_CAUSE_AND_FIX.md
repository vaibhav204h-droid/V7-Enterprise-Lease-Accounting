# V7.3 Round 12 — Payment Schedule Root Cause / Fix

## Root cause confirmed from the latest output
The supplied latest output had 1,309 payment rows. Several leases had payment blocks that no longer matched their current Lease Master contract dates. Examples from the same imported population were:

- LEASE-004: 45 rows in output vs 30 current-contract annual payments.
- LEASE-008: 84 rows vs 64 current-contract quarterly payments.
- LEASE-013: 30 rows vs 20 current-contract semi-annual payments.
- LEASE-018: 180 rows vs 120 current-contract monthly payments.
- LEASE-020: 228 rows vs 144 current-contract annual/monthly contractual schedule.

This proves the problem was deeper than blank formulas: stale payment blocks were being carried into the exported workbook.

## Second root cause
The report builder generated event formulas through `_event_formula_with_types()` but omitted the current payment row when calling `.format(...)`. The generated formula could retain `{row}`, producing a malformed Excel formula.

## Third root cause
The final export path used LibreOffice as a fallback recalculator. LibreOffice rewrites Excel formula syntax, including worksheet-reference quoting. That can trigger Excel content recovery and removal of formulas.

## Patch
1. Event formulas now always receive both `mr` and `row`.
2. A payment-schedule integrity gate rejects stale non-modified schedules before export.
3. Modified-regime payment rows use engine-snapshot formulas instead of falsely linking to original Lease_Master terms.
4. LibreOffice is no longer used as the final XLSX recalculation fallback. Native Excel COM is preferred; otherwise the structurally valid Excel workbook is left untouched for Excel to recalculate on open.
5. The existing sheet names, headers and calculation architecture are preserved.

## Acceptance focus
The software must calculate the contractual schedule from current Lease Master data on every successful portfolio run. No generated report may contain payment dates beyond the effective expiry for an unmodified lease.
