# V5.1 Enterprise Implementation Result

Reporting date default: **05-09-2026**. The central engine exposes one reporting-date parameter and no calculation module calls `date.today()`.

## Corrected source issues
- Windows-incompatible `/tmp/v5_import.xlsx` replaced by OS-safe temporary storage.
- Reporting-date defaults moved to 05-09-2026.
- Fixed-amount escalation separated from percentage escalation.
- Advance payment excluded from initial liability PV and included in ROU measurement as a payment made at/before commencement.
- Effective annual rate converted consistently for periodic/daily accruals.
- Reporting-date stub interest added.
- Current/non-current split added with reconciliation control.
- Security deposit is a separate Ind AS 109 schedule with EIR and ECL fields.
- Import is staged through validation/preview before confirmation.
- Import batches and company-scoped audit trail are stored.
- Errors are recorded rather than hidden by blanket zero substitution.
- Excel output includes formula-driven control cells and formula map.

## Existing-source observations
The supplied V5 app used `date.today()` in company/lease forms and hard-coded `/tmp/v5_import.xlsx` in the import function. Those are explicitly corrected in V5.1.

## Scope boundary
This package is an engineering/UAT build. The 20-case acceptance suite named in the development prompt cannot be certified from source code alone unless the actual 20-case input workbook is supplied. Five automated engine tests are included and pass.
