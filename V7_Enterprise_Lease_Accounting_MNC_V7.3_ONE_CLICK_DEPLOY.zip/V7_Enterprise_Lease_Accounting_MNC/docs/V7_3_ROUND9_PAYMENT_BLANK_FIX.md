# V7.3 Round 9 — Payment Schedule Blank Formula Fix

The supplied 20-lease workbook had 1,309 payment rows, of which 789 had a blank Payment (Formula) cell. Existing formula rows were preserved. Only blank payment cells were populated from the existing lease-level inputs.

The fix uses portable formulas and preserves support for Fixed %, Fixed Amount, Fixed Rate, CPI/CPI Linked, WPI/WPI Linked and Other Index. A defensive post-build pass was also added to the reporting engine so future generated reports cannot leave an otherwise valid payment row blank.

Verification of supplied workbook: 20 leases, 1,309 payment rows, 789 blank cells repaired, 520 existing payment formulas preserved, 0 blank payment cells after patch.
