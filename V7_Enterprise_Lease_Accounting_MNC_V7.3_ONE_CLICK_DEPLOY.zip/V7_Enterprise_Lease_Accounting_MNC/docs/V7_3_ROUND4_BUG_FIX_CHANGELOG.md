# V7.3 Round 4 Bug Fix Changelog

## Bug 1 — Security deposit day-one PV / deposit schedule
- `03_Initial_Recognition!H6:H...`: restored/retained the authoritative day-one deposit adjustment formula using the fully-qualified `01_Lease_Master!V` refund date.
- `03_Initial_Recognition!I6:I...`: continues to include the security-deposit day-one adjustment in Initial ROU.
- `06_IndAS109_Deposit!D` Period-1 rows: now derive the opening deposit PV from `Deposit Paid - 03_Initial_Recognition!H`, avoiding a duplicate broken PV calculation.
- Spot check for the supplied workbook: LEASE-001 Deposit Day-One Adjustment = ₹75,822.55 and Opening PV = ₹224,177.45 for the actual dates/inputs in this workbook.

## Bug 2 — Payment schedule portability
- `02_Payment_Schedule!E6:E...`: replaced the fragile LET/FILTER/REDUCE/SEQUENCE/LAMBDA formula with a portable `LOOKUP`/`SUMPRODUCT`/`SUMIFS`/`EXP` formula.
- Supports lease-scoped Reset Amount / New Base / Absolute Amount, Fixed Amount / Amount Increase and percentage/index-linked event types.
- Independent payment reconstruction uses the same portable path.
- Generated values recalculate successfully in LibreOffice without blank payment cells.

## Bug 3 — Current + non-current reconciliation
- `07_Current_NonCurrent` control formula retained against the engine's reporting liability and rounded to the workbook tolerance to avoid floating-point false failures.

## Bug 4 — GL reconciliation
- `14_Reconciliation!G6:G...`: blank GL Extract values are treated as unavailable, not as arithmetic errors; status falls back to Validator-vs-Excel variance.

## Workbook integrity / portability
- Workbook recalculated and saved through LibreOffice headless for cached values.
- XLSX ZIP/XML integrity test passed.
- Formula-length safety check: maximum formula length < 6,000 characters.
- Formula cache audit: no blank cached values remained in the targeted formula-heavy sheets.
