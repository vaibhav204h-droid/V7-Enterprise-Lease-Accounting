# V7.3 Round 6 — Modification Import & Reporting-Date Patch

## Targeted fixes
1. **Modification import duplicate handling**
   - `db/database.py:add_modification()` is now idempotent for the same `Modification_ID` + company + lease.
   - Re-submitting the same modification updates the existing row instead of raising `UNIQUE constraint failed: modifications.modification_id`.
   - A modification ID already belonging to another company/lease is rejected with a clear validation message.
   - No database table, existing column, or sheet structure is removed or renamed.

2. **Future-effective modifications**
   - `core/engine.py:calculate_lease_with_modifications()` now excludes modifications whose `effective_date` is after the selected reporting date.
   - Such future modifications remain in history/event records but do not affect the reporting-date lease liability, ROU, or other reported balances.
   - `app_v5.py:event_page()` only presents approved remeasurement events effective on or before the selected reporting date for processing into reporting-date modification calculations.
   - The UI now explicitly states that future-effective modifications are excluded from reporting-date measurement.

3. **Import error messaging**
   - The modification import commit path now gives a user-facing explanation if a duplicate-ID error is encountered, rather than exposing an opaque SQLite message.

## Test results
- Modification import idempotency test: PASS
- Future modification excluded from reporting-date measurement: PASS
- Existing V7.3 remediation tests: PASS
- Streamlit regression tests: PASS
- Combined targeted regression suite: **26 passed**
