# V5.2 QA Results — 05-09-2026

## User-reported defects addressed
1. Reporting date was not a true runtime-controlled date in all layers. V5.2 defaults to the current system date and permits a user-selected central reporting date.
2. Keyboard shortcut JavaScript only posted a message with no Streamlit navigation handler. V5.2 uses native Streamlit button shortcuts (Streamlit >= 1.60).
3. Excel import compatibility and persistence were improved: in-memory workbook loading, header-row detection, legacy V4 compatibility, Escalation_Amount mapping, staged preview and explicit commit.
4. Calculation was incorrectly amortising the complete lease to expiry even when the reporting date was earlier. V5.2 stops liability amortisation at the reporting date and calculates future principal only for the current/non-current split.
5. Small negative final balances were false critical errors caused by cumulative rounding. V5.2 keeps internal Decimal balances unrounded and rounds only outputs; immaterial residuals <= 0.10 are normalised to zero. Material negative balances remain blocked.

## 20-case regression using supplied test workbook
All 20 cases processed without calculation exceptions at reporting date 05-09-2026.

| Case | Payments | Reporting Liability | Current | Non-current | Reporting ROU |
|---|---:|---:|---:|---:|---:|
| TC-001 | 60 | 4,481,576.48 | 755,797.75 | 3,725,778.73 | 4,364,018.93 |
| TC-002 | 12 | 3,193,220.32 | 1,747,116.44 | 1,446,103.88 | 2,930,724.77 |
| TC-003 | 59 | 4,366,734.64 | 1,190,795.89 | 3,175,938.75 | 4,037,443.44 |
| TC-004 | 24 | 597,068.35 | 597,068.35 | 0.00 | 552,426.18 |
| TC-005 | 19 | 240,048.86 | 65,920.14 | 174,128.72 | 205,757.59 |
| TC-006 | 48 | 3,070,292.52 | 862,709.76 | 2,207,582.76 | 2,862,525.04 |
| TC-007 | 36 | 351,432.50 | 351,432.50 | 0.00 | 318,334.68 |
| TC-008 | 96 | 65,762,638.25 | 5,422,004.66 | 60,340,633.59 | 63,172,179.20 |
| TC-009 | 59 | 4,493,155.21 | 996,687.54 | 3,496,467.67 | 3,963,931.96 |
| TC-010 | 60 | 7,026,971.47 | 1,280,293.82 | 5,746,677.65 | 6,845,359.69 |
| TC-011 | 14 | 338,947.94 | 338,947.94 | 0.00 | 249,038.47 |
| TC-012 | 36 | 1,263,164.45 | 514,657.18 | 748,507.27 | 1,176,309.83 |
| TC-013 | 47 | 3,252,890.38 | 1,026,657.29 | 2,226,233.09 | 2,914,244.91 |
| TC-014 | 119 | 15,257,373.10 | 1,414,364.90 | 13,843,008.20 | 13,295,663.46 |
| TC-015 | 11 | 0.00 | 0.00 | 0.00 | 0.00 |
| TC-016 | 20 | 8,037,208.60 | 1,761,868.19 | 6,275,340.41 | 7,942,775.33 |
| TC-017 | 60 | 6,003,003.24 | 1,008,782.33 | 4,994,220.91 | 5,847,459.37 |
| TC-018 | 18 | 10,116,212.72 | 7,965,420.10 | 2,150,792.62 | 7,105,749.78 |
| TC-019 | 144 | 24,141,292.74 | 1,565,337.49 | 22,575,955.25 | 22,090,578.62 |
| TC-020 | 59 | 4,723,387.13 | 738,097.27 | 3,985,289.86 | 4,223,296.67 |

Portfolio totals:
- Initial lease liability: 192,345,520.66
- Reporting-date lease liability: 166,716,618.90
- Current: 29,603,959.54
- Non-current: 137,112,659.36
- Reporting ROU: 154,097,817.96

Control: Current + Non-current = Reporting Liability within 0.01 tolerance.

## Escalation controls
TC-006 fixed amount sequence is 90,000 → 95,000 → 100,000 → 105,000 at annual escalation points.
TC-013 fixed amount sequence is 95,000 → 102,500 → 110,000 → 117,500 at annual escalation points.
No trillion-level values were generated.

## Unit tests
5/5 existing automated tests passed.

## Remaining limitations
- Full MNC production deployment still requires organisation-specific SSO/MFA, production database, SAP/Oracle integration, approved GL mapping, IBR governance, ECL methodology, security testing and UAT.
- The three-way Independent Engine vs Excel Engine vs GL reconciliation and full JE/disclosure certification require the actual GL extracts and organisation-specific mappings.
