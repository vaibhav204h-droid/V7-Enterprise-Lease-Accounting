# V7.3 Round 9 — Latest Output Payment Schedule Remediation

## Root cause
The user's latest 20-lease output contained 1,309 payment rows, but column E (`Payment (Formula)`) had formulas in only 520 rows and was completely absent in 789 rows. Those rows were not legitimate zero-payment rows.

## Patch
Only the blank cells in `02_Payment_Schedule!E:E` were populated. The existing 520 formulas were left unchanged. Each repaired cell uses the existing `01_Lease_Master` inputs: Base Payment, Escalation Type, Escalation Amount / Rate, First Escalation Date and Escalation Frequency. The formulas are portable and do not use LET/FILTER/REDUCE/SEQUENCE/LAMBDA. Cached values are also present for immediate verification.

## Escalation semantics
- None: Base Payment
- Fixed % / Fixed Rate / index-linked fallback: Base Payment compounded from the contractual First Escalation Date using the Escalation Frequency
- Fixed Amount: Base Payment plus the contractual amount for each effective escalation
- Explicit event/custom-schedule leases keep their existing event formulas unchanged

## Result
All 1,309 payment rows now contain a formula and cached result. No formula-error literals were found in the workbook after the patch.

## Important
This remediation addresses the blank Payment Formula cells in the supplied latest output. It does not silently alter other downstream controls that may require separate reconciliation (for example, the supplied file's current/non-current portfolio control remained independently inconsistent after payment restoration).
