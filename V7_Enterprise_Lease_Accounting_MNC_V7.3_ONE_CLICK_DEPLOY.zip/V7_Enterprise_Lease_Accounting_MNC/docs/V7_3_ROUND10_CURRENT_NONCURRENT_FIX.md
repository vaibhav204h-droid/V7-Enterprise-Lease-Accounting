# V7.3 Round 10 — Current / Non-current Portfolio Tie-out

Targeted patch only; existing sheet names, headers and column order preserved.

`07_Current_NonCurrent!B6:B25` now uses the same reporting liability source as `00_Control!B9` (`04_Lease_Liability` reporting rows). `C6:C25` uses the next-12-month principal schedule and is capped at total reporting liability. `D6:D25` is the residual non-current amount. `E6:E25` remains the reconciliation check.

The workbook cache was refreshed for the delivered report so `00_Control!B13` equals `00_Control!B9` on open, and full recalculation is requested when opened in Excel.

Engine reporting liability total in the patched workbook: ₹11,336,301.59.
