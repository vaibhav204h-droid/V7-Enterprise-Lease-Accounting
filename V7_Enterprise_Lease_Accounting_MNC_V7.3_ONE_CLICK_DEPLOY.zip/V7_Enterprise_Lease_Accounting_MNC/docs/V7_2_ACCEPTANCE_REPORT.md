# V7.2 FINAL FORENSIC REPAIR & ACCEPTANCE REPORT

**System:** Ind AS 116 / Ind AS 109 / Ind AS 21 Lease Accounting Automation
**Release:** V7.2
**Portfolio:** VGH — 10 active leases
**Reporting date:** 06-Sep-2026
**Tolerance:** INR ₹0.01; foreign currency 0.01 unit where applicable

## 1. Certification

**Software release status: GREEN for the tested V7.2 package.**

This certification means the repaired package passed the documented V7.2 software acceptance tests and the supplied 10-lease workbook reconciliation. It is **not** a blanket assertion that every future client data set is audit-ready; approved inputs, accounting policy conclusions, evidence, GL reconciliation and reviewer approval remain required.

## 2. Repairs completed

- V7.2 application/engine/validation versioning.
- Lease-scoped, deterministic escalation ordering using Effective Date + Event Sequence.
- Corrected uniform escalation interval logic.
- Excel payment schedule no longer depends on fixed global escalation rows.
- Excel liability roll-forward now starts from Initial Recognition and correctly handles reporting dates before the first contractual payment.
- Formula-driven current/non-current calculation using projected future principal over the next 12 months.
- Real Excel date values used for reporting and contractual dates.
- Initial ROU formula includes the rounded security-deposit day-one lease adjustment.
- ROU depreciation uses assessed effective expiry and rounded monthly depreciation consistent with the engine.
- Formula-driven security-deposit amortised-cost/ECL working.
- Formula-driven maturity analysis.
- Separate independent validation engine.
- Workbook reconciliation references independent validation evidence.
- ₹0.01 workbook control tolerance.
- Added V7.2 acceptance tests.

## 3. Mandatory test results

| Test | Result |
|---|---|
| Legacy regression suite | 39/39 PASS |
| V7.2 deterministic acceptance tests excluding randomized stress | 43 PASS / 1 stress test separately executed |
| V7.2 randomized independent scenarios | 10,000 PASS |
| L-001 mandatory escalation | PASS |
| L-008 full liability / ROU / current-non-current / JE chain | PASS |
| Independent validator maximum reporting-liability variance | ₹0.00 |
| Workbook Initial Recognition controls | 10/10 PASS |
| Workbook Liability controls | 10/10 PASS |
| Workbook ROU controls | 0 CHECK rows |
| Workbook Current/Non-current controls | 10/10 PASS |
| Workbook Engine/Excel reconciliation | Maximum variance < ₹0.01 |
| Workbook Future Liability controls | 0 CHECK rows |

## 4. L-001 escalation acceptance

Base payment ₹350,000. Required outputs:

- 01-Apr-2027: **₹371,000.00**
- 01-Apr-2029: **₹396,000.00**
- 01-Apr-2030: **₹427,680.00**

All pass at ₹0.01 tolerance.

## 5. L-008 acceptance

| Metric | V7.2 result |
|---|---:|
| Initial lease liability | ₹43,089,873.50 |
| Reporting lease liability | ₹44,816,369.63 |
| Current liability | ₹2,832,958.15 |
| Non-current liability | ₹41,983,411.48 |
| Current + non-current | ₹44,816,369.63 |
| Initial ROU | ₹54,018,078.20 |
| Reporting ROU | ₹52,217,475.62 |
| Security deposit paid | ₹5,000,000.00 |
| Security deposit initial FV | ₹1,811,222.60 |
| Day-one difference | ₹3,188,777.40 |
| Deposit ECL | ₹33,570.97 |
| JE balance | PASS |

The former Excel zero-liability defect is eliminated.

## 6. Reporting-date test

L-008 reporting liability changed dynamically across 31-Mar-2026, 30-Jun-2026, 31-Aug-2026, 06-Sep-2026, 30-Sep-2026 and 31-Mar-2027. No stale fixed reporting value was used.

## 7. Independent validation

A separate `core/independent_validator.py` reconstructs contractual dates, escalation, PV, liability roll-forward and current/non-current split without calling the production `calculate()` routine. Maximum reporting-liability variance across the supplied 10 leases was **₹0.00**.

## 8. Workbook reconciliation

The recalculated V7.2 workbook was opened/recalculated through LibreOffice Calc and re-read with `data_only=True`. All mandatory workbook control columns contained no CHECK/ERROR rows. The maximum supplied 10-lease validator-to-workbook reporting-liability variance was below ₹0.01.

## 9. Known limitations / required accounting-policy confirmation

1. FX is exposed as a monetary-balance reporting conversion layer; a complete transaction-date FX ledger requires transaction-level FX data.
2. Modification/remeasurement conclusions remain dependent on approved modification facts and the entity's accounting policy.
3. Restoration provision uses a 365-day convention and should be aligned with the entity's documented policy.
4. Security-deposit ECL requires documented PD/LGD/EAD or another defensible Ind AS 109 methodology and forward-looking assumptions.
5. GL reconciliation is blocked until a real GL extract is supplied.

## 10. Acceptance gate

**GREEN — software acceptance passed for the supplied V7.2 package and test portfolio.**
