@echo off
setlocal EnableExtensions
title V7.3 Enterprise Lease Accounting - One Click Deployment

echo ============================================================
echo   V7.3 Enterprise Lease Accounting - ONE CLICK DEPLOY
echo ============================================================
echo.

cd /d "%~dp0"
set "APP_ROOT=%~dp0"
if exist "%~dp0requirements.txt" set "APP_ROOT=%~dp0"
if exist "%~dp0V7_Enterprise_Lease_Accounting_MNC\requirements.txt" set "APP_ROOT=%~dp0V7_Enterprise_Lease_Accounting_MNC"

cd /d "%APP_ROOT%"

echo [1/6] Checking Python...
where py >nul 2>&1
if %errorlevel%==0 (
    set "PY=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo.
        echo ERROR: Python was not found.
        echo Please install Python 3.11 or later and run this file again.
        pause
        exit /b 1
    )
)

echo [2/6] Creating isolated virtual environment...
if not exist ".venv\Scripts\python.exe" (
    %PY% -m venv .venv
    if errorlevel 1 (
        echo ERROR: Could not create virtual environment.
        pause
        exit /b 1
    )
)

set "VENV_PY=%APP_ROOT%\.venv\Scripts\python.exe"

echo [3/6] Installing/updating required packages...
if exist "%APP_ROOT%\requirements.txt" (
    "%VENV_PY%" -m pip install --upgrade pip
    "%VENV_PY%" -m pip install -r "%APP_ROOT%\requirements.txt"
    if errorlevel 1 (
        echo.
        echo ERROR: Dependency installation failed.
        pause
        exit /b 1
    )
) else (
    echo WARNING: requirements.txt not found.
    echo Skipping dependency installation.
)

echo [4/6] Running regression tests...
"%VENV_PY%" -m pytest
if errorlevel 1 (
    echo.
    echo WARNING: Regression tests reported failures.
    echo The application will NOT be launched automatically.
    echo Review the test output before production use.
    pause
    exit /b 1
)

echo [5/6] Locating Streamlit application...
set "APP_FILE="
if exist "%APP_ROOT%\app.py" set "APP_FILE=%APP_ROOT%\app.py"
if not defined APP_FILE if exist "%APP_ROOT%\main.py" set "APP_FILE=%APP_ROOT%\main.py"

if not defined APP_FILE (
    for /r "%APP_ROOT%" %%F in (*.py) do (
        echo %%~nxF | findstr /i /r "^app\.py$ ^main\.py$" >nul
        if not errorlevel 1 set "APP_FILE=%%F"
    )
)

if not defined APP_FILE (
    echo ERROR: Could not locate app.py or main.py.
    pause
    exit /b 1
)

echo [6/6] Starting V7.3 Enterprise Lease Accounting...
echo.
echo Application: %APP_FILE%
echo.
echo The browser should open automatically.
echo If it does not, open:
echo http://localhost:8501
echo.
echo Keep this window open while using the software.
echo.

"%VENV_PY%" -m streamlit run "%APP_FILE%"

pause
